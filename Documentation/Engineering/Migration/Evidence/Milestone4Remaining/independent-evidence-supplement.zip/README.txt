This supplements the reports and compressed test logs committed in PR33 at ecdb529.
It includes raw exported simulator result trees, source manifests, original reports,
negative reciprocal-test sentinel evidence, preserved execution-runner versions,
and independent audit results. It does not include DerivedData binaries or whole
xcresult bundles. Existing reports retain original machine paths; use manifest.json
for the archive-relative file mapping and SHA256 integrity verification.

The old iOS26.5 Release run did not capture the execution runner hash or live built
binary hashes before cleanup. This limit cannot be repaired retroactively.
For iOS26.0, the original validator report and runner were recovered against their
recorded exact SHA256 hashes after an offline validator self-test correction.
Native macOS object equality does not establish iOS or Swift6.2 object equality.
No CI success, exactmacOS26.0 qualification, or whole Milestone4 completion is claimed.
