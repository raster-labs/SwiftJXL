from pathlib import Path
p=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public/Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift')
s=p.read_text()
def edit(start,end,changes):
    global s
    a=s.index(start);b=s.index(end,a);part=s[a:b]
    for old,new in changes:
        assert old in part, (start,old)
        part=part.replace(old,new)
    s=s[:a]+part+s[b:]

edit('    private static func learnedThresholdSets(', '    /// Analytically cost the multi-group', [
 ('private static func learnedThresholdSets','static func learnedThresholdSets'),
 ('postCfg: HybridUintConfig, maxDepth: Int\n    ) ->', 'postCfg: HybridUintConfig, maxDepth: Int,\n        checkpoint: () throws -> Void = ScalarEncodingWork.checkpoint\n    ) throws ->'),
 ('let sorted = pairs.sorted { $0.wpProp < $1.wpProp }', '''guard maxDepth <= 3 else { throw ScalarModularError.resourceLimit }
        try checkpoint()
        try ModularEffortWork.reserve(samples: n, bytesPerSample: 64, fixed: 128 * 1024)
        var sorted = pairs
        try ModularEffortWork.sort(&sorted, by: { $0.wpProp < $1.wpProp }, checkpoint: checkpoint)'''),
 ('let toks = sorted.map { Int(postCfg.encode($0.token).token) }', '''var toks = [Int]()
        toks.reserveCapacity(n)
        for (i, pair) in sorted.enumerated() {
            if i & 1023 == 0 { try checkpoint() }
            toks.append(Int(postCfg.encode(pair.token).token))
        }'''),
 ('clogc[c] = Double(c)', 'if c & 1023 == 0 { try checkpoint() }\n            clogc[c] = Double(c)'),
 ('func bestSplit(_ lo: Int, _ hi: Int) ->', 'func bestSplit(_ lo: Int, _ hi: Int) throws ->'),
 ('for i in lo..<hi { hiCount[toks[i]] += 1; hiTotal += 1 }', '''for i in lo..<hi {
                if i & 1023 == 0 { try checkpoint() }
                hiCount[toks[i]] += 1; hiTotal += 1
            }'''),
 ('let tk = toks[i]', 'if i & 1023 == 0 { try checkpoint() }\n                    let tk = toks[i]'),
 ('= bestSplit(lo, hi)', '= try bestSplit(lo, hi)'),
 ('return sets', 'try checkpoint()\n        return sets')])

edit('    private static func costMultiGroupSections(', '    /// Emit the multi-group', [
 ('var histo = [[Int]](', '''let samples = try perGroupOrdered.reduce(0) { try ScalarOperationBudget.sum($0, $1.count) }
        try ModularEffortWork.reserveCost(samples: samples, contexts: n, groups: numGroups)
        var histo = [[Int]](''')])
edit('    private static func emitMultiGroupSections(', '    /// Cost + emit', [
 ('var dcGlobal = BitWriter()', '''let samples = try perGroupOrdered.reduce(0) { try ScalarOperationBudget.sum($0, $1.count) }
        try ModularEffortWork.reserveEmission(samples: samples, contexts: n, groups: numGroups)
        var dcGlobal = BitWriter()''')])

edit('    private static func buildSectionsMultiContext(', '    private static func buildSectionsGreedyTree(', [
 ('let postCfg = HybridUintConfig.raw4', '''let postCfg = HybridUintConfig.raw4
        let samples = try ScalarOperationBudget.product(ScalarOperationBudget.product(width, height), channels.count)
        try ModularEffortWork.reserve(samples: 1, bytesPerSample:
            ModularEffortWork.collectionWorkspace(width: width, height: height,
                channels: channels.count, groups: numGroups, tree: false))'''),
 ('for ry in 0..<rectH {', 'for ry in 0..<rectH {\n                try ScalarEncodingWork.checkpoint()'),
 ('for p in run { allProps.append(p.wpProp) }', '''try ScalarEncodingWork.checkpoint()
                for (i, p) in run.enumerated() {
                    if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
                    allProps.append(p.wpProp)
                }'''),
 ('allProps.sort()', 'try ModularEffortWork.sort(&allProps, by: <)'),
 ('''let perGroupOrdered = perGroupPixels.map { group in
                group.map { (ctx: ctxOf($0.wpProp), val: $0.token) }
            }''', '''try ModularEffortWork.reserve(samples: samples, bytesPerSample: 32,
                fixed: ScalarOperationBudget.product(numGroups, 256))
            var perGroupOrdered = [[(ctx: Int, val: UInt32)]]()
            for group in perGroupPixels {
                var ordered = [(ctx: Int, val: UInt32)]()
                ordered.reserveCapacity(group.count)
                for (i, p) in group.enumerated() {
                    if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
                    ordered.append((ctxOf(p.wpProp), p.token))
                }
                perGroupOrdered.append(ordered)
            }'''),
 ('''for l in learnedThresholdSets(
            pairs: perGroupPixels.flatMap { $0 }, postCfg: postCfg, maxDepth: 3)''', '''var learningPairs = [(wpProp: Int32, token: UInt32)]()
        learningPairs.reserveCapacity(samples)
        for group in perGroupPixels {
            for (i, pair) in group.enumerated() {
                if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
                learningPairs.append(pair)
            }
        }
        for l in try learnedThresholdSets(
            pairs: learningPairs, postCfg: postCfg, maxDepth: 3)''')])

edit('    private static func buildSectionsGreedyTree(', '    private static func writeGlobalTreeAndPostCodebook(', [
 ('var perGroupProps =', '''try ModularEffortWork.reserve(samples: 1, bytesPerSample:
            ModularEffortWork.collectionWorkspace(width: width, height: height,
                channels: channels.count, groups: numGroups, tree: true))
        try ModularEffortWork.reserve(samples: min(n, ModularLearningSamples.maximumCount), bytesPerSample: 64)
        var perGroupProps ='''),
 ('for ry in 0..<rectH {', 'for ry in 0..<rectH {\n                        try ScalarEncodingWork.checkpoint()'),
 ('= greedyTreeAndContexts(', '= try greedyTreeAndContexts('),
 ('var perGroupOrdered =', '''try ModularEffortWork.reserve(samples: n, bytesPerSample: 32,
            fixed: ScalarOperationBudget.product(numGroups, 256))
        var perGroupOrdered =''')])

edit('    private static func costMultiContextSection(', '    /// Emit the full section', [
 ('var histo = [[Int]](', '''try ModularEffortWork.reserveCost(samples: ordered.count, contexts: n, groups: 1)
        var histo = [[Int]](''')])
edit('    private static func emitMultiContextSection(', '    private static func assembleMultiContextSection(', [
 ('var sec = BitWriter()', '''try ModularEffortWork.reserveEmission(samples: ordered.count, contexts: n, groups: 1)
        var sec = BitWriter()''')])
edit('    private static func buildSingleSectionMultiContext(', '    /// Sorts the first', [
 ('let postCfg = HybridUintConfig.raw4', '''let postCfg = HybridUintConfig.raw4
        try ModularEffortWork.reserve(samples: 1, bytesPerSample:
            ModularEffortWork.collectionWorkspace(width: width, height: height,
                channels: channels.count, groups: 1, tree: false))'''),
 ('for i in 0..<count {', 'for i in 0..<count {\n                if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }'),
 ('for y in 0..<height {', 'for y in 0..<height {\n                    try ScalarEncodingWork.checkpoint()'),
 ('let sortedProps = perPixel.map { $0.wpProp }.sorted()', '''var sortedProps = [Int32]()
        sortedProps.reserveCapacity(perPixel.count)
        for (i, pixel) in perPixel.enumerated() {
            if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
            sortedProps.append(pixel.wpProp)
        }
        try ModularEffortWork.sort(&sortedProps, by: <)'''),
 ('var ordered: [(ctx: Int, val: UInt32)] = []', '''try ModularEffortWork.reserve(samples: perPixel.count, bytesPerSample: 32, fixed: 256)
            var ordered: [(ctx: Int, val: UInt32)] = []'''),
 ('for (wpProp, tok) in perPixel { ordered.append((ctxOf(wpProp), tok)) }', '''for (i, pixel) in perPixel.enumerated() {
                if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
                ordered.append((ctxOf(pixel.wpProp), pixel.token))
            }'''),
 ('for l in learnedThresholdSets(', 'for l in try learnedThresholdSets(')])

edit('    private static func radixSortInt64Prefix(', '    /// Learn a greedy', [
 ('counts: inout [Int], count m: Int\n    ) {', 'counts: inout [Int], count m: Int,\n        checkpoint: () throws -> Void\n    ) throws {'),
 ('guard m > 1', 'try checkpoint()\n        guard m > 1'),
 ('a.withUnsafeBufferPointer', 'try a.withUnsafeBufferPointer'),
 ('counts.withUnsafeMutableBufferPointer', 'try counts.withUnsafeMutableBufferPointer'),
 ('tmp.withUnsafeMutableBufferPointer { tp in scatter(ap, tp) }', 'try tmp.withUnsafeMutableBufferPointer { tp in try scatter(ap, tp) }'),
 ('tmp.withUnsafeBufferPointer', 'try tmp.withUnsafeBufferPointer'),
 ('a.withUnsafeMutableBufferPointer { ap in scatter(tp, ap) }', 'try a.withUnsafeMutableBufferPointer { ap in try scatter(tp, ap) }'),
 ('for i in 0..<m {', 'for i in 0..<m {\n                    if i & 1023 == 0 { try checkpoint() }'),
 ('_ dst: UnsafeMutableBufferPointer<Int64>) {', '_ dst: UnsafeMutableBufferPointer<Int64>) throws {'),
 ('offsets.withUnsafeMutableBufferPointer', 'try offsets.withUnsafeMutableBufferPointer'),
 ('a.withUnsafeMutableBufferPointer { ap in\n', 'try a.withUnsafeMutableBufferPointer { ap in\n')])

edit('    private static func greedyTreeAndContexts(', '    /// Greedy multi-property MA-tree candidate', [
 ('private static func greedyTreeAndContexts', 'static func greedyTreeAndContexts'),
 ('maxTok: Int, maxLeaves: Int, minGain: Double\n    ) ->', 'maxTok: Int, maxLeaves: Int, minGain: Double,\n        checkpoint: () throws -> Void = ScalarEncodingWork.checkpoint\n    ) throws ->'),
 ('guard n >= 2, propCount >= 1 else { return nil }', '''guard n >= 2, propCount >= 1 else { return nil }
        guard propCount <= 6, (0..<256).contains(maxTok),
              tokBucket.count == n,
              propsFlat.count == (try ScalarOperationBudget.product(n, propCount)) else {
            throw ScalarModularError.invalidInput("Invalid Modular learner input")
        }
        try checkpoint()
        try ModularEffortWork.reserve(samples: 1, bytesPerSample:
            ModularEffortWork.learnerWorkspace(samples: n, leaves: maxLeaves))
        for (i, token) in tokBucket.enumerated() {
            if i & 1023 == 0 { try checkpoint() }
            guard (0...maxTok).contains(token) else {
                throw ScalarModularError.invalidInput("Invalid Modular learner token")
            }
        }'''),
 ('clogc[c] = Double(c)', 'if c & 1023 == 0 { try checkpoint() }\n            clogc[c] = Double(c)'),
 ('_ radixCounts: inout [Int], _ loBuf: inout [Int]\n        ) {', '_ radixCounts: inout [Int], _ loBuf: inout [Int]\n        ) throws {'),
 ('node.bestGain = -1; node.bestK = -1', 'try checkpoint()\n            node.bestGain = -1; node.bestK = -1'),
 ('for i in node.idxs { nodeHist[tokBucket[i]] += 1 }', '''for (j, i) in node.idxs.enumerated() {
                if j & 1023 == 0 { try checkpoint() }
                nodeHist[tokBucket[i]] += 1
            }'''),
 ('for (i, idx) in node.idxs.enumerated() {', 'for (i, idx) in node.idxs.enumerated() {\n                    if i & 1023 == 0 { try checkpoint() }'),
 ('radixSortInt64Prefix(\n', 'try radixSortInt64Prefix(\n'),
 ('counts: &radixCounts, count: m)', 'counts: &radixCounts, count: m, checkpoint: checkpoint)'),
 ('let tk = Int(packedBuf[j] & 0xffff)', 'if j & 1023 == 0 { try checkpoint() }\n                        let tk = Int(packedBuf[j] & 0xffff)'),
 ('let root = GNode(Array(0..<n))', '''var rootIndices = [Int]()
        rootIndices.reserveCapacity(n)
        for i in 0..<n {
            if i & 1023 == 0 { try checkpoint() }
            rootIndices.append(i)
        }
        let root = GNode(rootIndices)'''),
 ('computeBest(root,', 'try computeBest(root,'),
 ('while leaves.count < maxLeaves {', 'while leaves.count < maxLeaves {\n            try checkpoint()'),
 ('for i in node.idxs {\n', 'for (j, i) in node.idxs.enumerated() {\n                if j & 1023 == 0 { try checkpoint() }\n'),
 ('computeBest(L,', 'try computeBest(L,'), ('computeBest(R,', 'try computeBest(R,'),
 ('for i in g.idxs { contexts[i] = lid }', '''for (j, i) in g.idxs.enumerated() {
                    if j & 1023 == 0 { try checkpoint() }
                    contexts[i] = lid
                }'''),
 ('return (ModularTree(nodes: nodesOut), contexts, leafCounter)', 'try checkpoint()\n        return (ModularTree(nodes: nodesOut), contexts, leafCounter)')])

edit('    private static func buildSingleSectionGreedyTree(', '    /// Pick the smaller', [
 ('var sp = [Int32](); var st = [Int]()', '''try ModularEffortWork.reserve(samples: learningSamples.count, bytesPerSample: 64)
            var sp = [Int32](); var st = [Int]()'''),
 ('= greedyTreeAndContexts(', '= try greedyTreeAndContexts('),
 ('var ordered: [(ctx: Int, val: UInt32)] = []', '''try ModularEffortWork.reserve(samples: n, bytesPerSample: 32, fixed: 256)
        var ordered: [(ctx: Int, val: UInt32)] = []''')])
p.write_text(s)
