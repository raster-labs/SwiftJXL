from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess,zipfile
w=Path(__file__).resolve().parent
out=w.parent.parent/'outputs'
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
base='ffeeef7e9f8807a6ad575ba416842df984bf8283'
def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,obj): path.write_text(json.dumps(obj,indent=2)+'\n')
finalHashes={str(p.relative_to(repo)):digest(p) for folder in ['Sources','Tests'] for p in (repo/folder).rglob('*.swift')}
validation=[]
for config in ['debug','release','asan','tsan']:
    d=read(w/f'sampling-{config}.json'); assert d['exit']==0 and d['sourceHashes']==finalHashes
    assert d['xml']['failures']==d['xml']['errors']==d['xml']['skips']==0
    log=(w/f'sampling-{config}.log').read_text()
    parameterised=[int(x) for x in re.findall(r'✔ Test [^\n]+ with (\d+) test cases passed',log)]
    d['cases']=d['xml']['declarations']-len(parameterised)+sum(parameterised)
    d['evidence']=f'sampling-{config}.json';d.pop('sourceHashes')
    assert not re.search(r'(ERROR: AddressSanitizer|WARNING: ThreadSanitizer|SUMMARY: (?:AddressSanitizer|ThreadSanitizer))',log)
    validation.append(d)
build=read(w/'candidate/build.json')
assert all(finalHashes[p]==h for p,h in build['sourceHashes'].items())
assert digest(w/'candidate/probe')==build['binarySHA256']
reuse=read(w/'baseline-reuse.json');assert reuse['mismatches']==[] and reuse['matchedSourceFiles']==98
assert digest(w/'baseline/probe')==reuse['priorBuild']['binarySHA256']
assert digest(w/'probe.swift')==build['probeSHA256']==reuse['priorBuild']['probeSHA256']
small=read(w/'candidate-preflight/report.json');large=read(w/'large-preflight/report.json');policy=read(w/'policy/report.json')
assert small['status']==large['status']==policy['status']=='passed'
assert len(small['cases'])==54 and len(large['cases'])==7 and len(policy['cases'])==42
comparisons=[]
for label in ['initial','repeat']:
 d=read(w/label/'report.json');assert d['status']=='completed' and len(d['cases'])==7
 for row in d['cases']:
  independent=next(r for r in large['cases'] if r['name']==row['name'])
  for run in row['runs']:
   oracle=next(r for r in independent['runs'] if r['implementation']==run['implementation'])
   assert run['codestreamSHA256']==oracle['sha256']
 comparisons.append({'label':label,'order':d['order'],'scope':d['scope'],'cases':[{k:v for k,v in r.items() if k!='runs'} for r in d['cases']]})
previous=read(Path('/Users/raster/Documents/Codex/2026-10-13/swiftjxl-milestone4-remaining-qualification/outputs/modular-learning-cap-qualification.json'))
contracts={'Documentation/'+p:h for p,h in previous['commonContractHashes'].items()};assert all(digest(repo/p)==h for p,h in contracts.items())
report={
 'asOfUTC':datetime.now(timezone.utc).isoformat(),
 'status':'Scoped correctness and safety validation complete; measured higher-effort performance trade-off, hosted validation and wider Milestone 4 gates remain open.',
 'branch':'codex/swiftjxl-modular-effort-budget','base':base,'mergedPrerequisites':[26,27],'targetBaseBranch':'main','targetBaseHead':'b4020581fe5c8ca1319bf783eb304afb28909cb2','targetBaseTreeMatchesBenchmarkBase':True,
 'contract':'0.10.0','predecessorPin':'57e81cb9e2411d1efac435b429a306a031744c1e',
 'change':['Admit activity/grouped-tree collection, every routing/costing candidate, selected emission and capped learner storage against the shared cumulative workspace and aggregate-memory ledger.',
           'Check activity sorting/learning and greedy histogram, radix, partition and context work at bounded sample intervals. Stable sort ties and candidate selection remain unchanged.',
           'Retain public effort 3, its admission model, worker ceilings, ownership and contract unchanged.'],
 'validation':validation,
 'priorStage':{'directories':['pre-bounded-sort','pre-chunk-loops','radix-chunk-diagnostic'],'scope':'Retained superseded source, successful tests and performance investigation. Final tests above are authoritative for the final bounded-block implementation.'},
 'independentOracle':{'tool':'djxl 0.12.0 from /opt/homebrew/bin','smallCases':54,'largerControlCases':7,'largerIndependentDecodes':14,'sampleFidelity':'Exact on every decoded sample','encodedBytes':'Unchanged against PR27 for all tested cases','timedStreamsMatchIndependentlyDecodedHashes':True,'evidence':['candidate-preflight/report.json','large-preflight/report.json']},
 'policy':{'evidence':'policy/report.json','cases':42,'workers':[1,2,8],'efforts':[7,9],'result':'All ample-budget outputs match PR27; all old-limit baseline encodes succeed while the candidate rejects omitted workspace with resourceLimit. Exact candidate boundaries and aggregate-memory limits are separately covered by regression tests.','minimumCandidateReservationBytes':min(r['candidate']['reservedWorkspace'] for r in policy['cases']),'maximumCandidateReservationBytes':max(r['candidate']['reservedWorkspace'] for r in policy['cases']),'telemetryClaim':False},
 'comparisons':comparisons,
 'measurementProtocol':{'warmupsPerBlock':5,'timedIterationsPerBlock':10,'timedIterationsPerImplementationPerCasePerComparison':20,'orders':['baseline,candidate,candidate,baseline','candidate,baseline,baseline,candidate'],'noConcurrentLocalQualificationJobs':True,'evidence':'measurement-window.json'},
 'sourceAndTestHashes':finalHashes,'commonContractHashes':contracts,
 'baselineReuse':{'base':base,'matchedSourceFiles':98,'rebuilt':False,'evidence':'baseline-reuse.json'},
 'environment':{'compiler':build['compiler'],'os':build['os'],'target':'arm64-apple-macos26.0'},
 'limitations':[
  'Public API/CLI effort remains 3; no new public effort control or production cutover.',
  'Component reservations require the caller effort-3 envelope and are cumulative conservative bounds, not allocator measurements. They can reject work whose actual peak allocation would fit.',
  'Algorithm checkpoints bound changed loop work; allocator/COW/runtime copies and scheduling have no real-time cancellation guarantee.',
  'Timing comparisons exercise serial internal encodes without an operation-budget context. The separate budget probe covers one, two and eight workers, not concurrent steady-state telemetry.',
  'Process peak RSS is process-wide; allocation counts, copy-byte telemetry, peak algorithm workspace and widest profile/precision/corpus coverage remain open.',
  'Local Swift 6.4 macOS arm64 evidence does not qualify hosted Swift 6.2, both Linux architectures or minimum-OS/device runtime.',
  'Existing public Modular predecessor performance gaps and JPEG/VarDCT/animation/feature/platform gates remain open. Milestone 4 is incomplete; JXLSwift remains the supported production route.'
 ],
 'retainedIssues':['Initial oracle driver used a stale baseline-preflight path; corrected to the verified existing PR27 fixtures. The failed driver output is retained.',
                   'Initial comparison-sort checkpoints did not bound all long element moves. Source review replaced that design with bounded runs and checkpointed merges; earlier evidence remains under pre-bounded-sort.',
                   'Removed stale pre-PR27 learning-population labels from reused large-case report metadata; measured commands, outputs and results were unchanged.']}
regressions=[]
for i,row in enumerate(comparisons[0]['cases']):
    both=[comparison['cases'][i]['summaries'] for comparison in comparisons]
    latency=[r['medianChangePercent'] for r in both]
    rss=[(r['candidate']['processPeakRSSBytes']/r['baseline']['processPeakRSSBytes']-1)*100 for r in both]
    if all(x>5 for x in latency) or all(x>5 for x in rss):
        regressions.append({'case':row['name'],'latencyChangePercent':latency,'peakRSSChangePercent':rss})
    for comparison in comparisons:
        r=comparison['cases'][i]
        for implementation in ['baseline','candidate']:
            r['summaries'][implementation]['medianPixelsPerSecond']=r['width']*r['height']*1000/r['summaries'][implementation]['medianMS']
report['performanceGate']={'status':'Open; no stable-release acceptance or baseline waiver.',
 'confirmedOverFivePercent':regressions,
 'reason':'Higher-effort safety checks and bounded stable sorting add work. The initial implementation reproduced roughly 8-11 percent tree-case overhead. Moving checks outside tight radix and learner blocks reduced the measured cost; remaining cost is explicitly retained for review, not silently waived. Activity-gray process RSS also rises about 5.5 percent in both runs; the stable merge uses an admitted full-length scratch array, but allocator-level attribution is not established.',
 'investigation':['pre-chunk-loops/initial/report.json','pre-chunk-loops/repeat/report.json','radix-chunk-diagnostic/chunk-diagnostic/report.json','learner-diagnostic/report.json'],
 'scope':'Internal effort-8/9 median latency and effort-7 activity-gray process RSS exceed the repeated 5-percent threshold; public effort-3 control has no repeated regression.'}
report['limitations'].insert(0,'Repeated internal effort-8/9 median latency and effort-7 activity-gray process RSS increases exceed the PERF-03 investigation threshold. The safety/performance trade-off remains open for review before accepting a release baseline.')
write(out/'modular-effort-budget-qualification.json',report)
review={'asOfUTC':report['asOfUTC'],'reviewer':'Current coding agent, fresh source/diff review; not an independent GitHub approval','base':base,'reviewedSourceAndTestHashes':finalHashes,'correctnessFindings':[],'qualificationFindings':[report['performanceGate']],
 'scope':['Checked all new reservations against visible higher-effort array/table/writer lifetimes and bounded dimensions, contexts, groups and exact learning cap.',
          'Reviewed sort and radix synchronous unsafe borrows, scratch COW separation, overflow-safe merge bounds, stable ties and cancellation unwind.',
          'Confirmed errors propagate under PR26 policy, shared operation state/worker joining unchanged, and public API/CLI still selects effort 3.',
          'Verified final test/build hashes, deterministic old/new budget reproduction, independent oracle hashes and repeated performance evidence.'],
 'limitations':report['limitations']}
write(out/'modular-effort-budget-review.json',review)
# Preserve commands, logs, reports and source snapshots, excluding compiled binaries
# and bulky generated image/codestream payloads whose hashes are already recorded.
zipPath=out/'modular-effort-budget-evidence.zip'
with zipfile.ZipFile(zipPath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(w.rglob('*')):
  if not p.is_file() or any(part in ['cache','baseline','baseline-preflight'] for part in p.relative_to(w).parts):continue
  if p.suffix not in ['.py','.swift','.txt','.json','.log','.xml','.md']:continue
  z.write(p,str(p.relative_to(w)))
 z.writestr('baseline/build.json',(w/'baseline/build.json').read_text())
 z.writestr('qualification.json',json.dumps(report,indent=2)+'\n')
 z.writestr('review.json',json.dumps(review,indent=2)+'\n')
evidence=repo/'Documentation/Engineering/Migration/Evidence/ModularEffortBudget';evidence.mkdir(exist_ok=True)
(evidence/'qualification.json').write_bytes((out/'modular-effort-budget-qualification.json').read_bytes())
(evidence/'raw-evidence.zip').write_bytes(zipPath.read_bytes())
(evidence/'README.md').write_text('# Higher-effort admission and cancellation evidence\n\nSee [the scoped report](../../MODULAR_EFFORT_BUDGET.md), [qualification index](qualification.json) and [raw evidence](raw-evidence.zip). The archive retains commands, final and superseded validation, source hashes, synthetic probe generators, independent-decoder logs, policy comparisons and both interleaved timing runs. Absolute paths record the executed environment; adjust work/repository paths when reproducing. Compiled products and generated image payloads are omitted; their output hashes remain in the reports. Public encoding remains at effort 3.\n')
print(json.dumps({'validation':[(v['configuration'],v['xml']['declarations'],v['cases']) for v in validation],'archiveBytes':zipPath.stat().st_size,'sourceFiles':len(finalHashes)}))
