import Foundation
import SwiftJXLCore

@main struct PolicyProbe {
    static func main() throws {
        let args = CommandLine.arguments
        let width = Int(args[1])!, height = Int(args[2])!, channels = Int(args[3])!
        let effort = Int(args[4])!, workers = Int(args[5])!, workspace = Int(args[6])!
        let n = width * height
        let budget = try ScalarOperationBudget(retainedBytes: n * channels * 2,
            maximumWorkspaceBytes: workspace, maximumMemoryBytes: 4 * 1024 * 1024 * 1024,
            maximumDecodedBytes: 128 * 1024 * 1024, maximumCompressedBytes: 128 * 1024 * 1024,
            deadline: .now.advanced(by: .seconds(120)), maximumWorkers: workers)
        var report: [String: Any] = ["width": width, "height": height, "channels": channels,
            "effort": effort, "workers": workers, "workspaceLimit": workspace]
        do {
            let limit = try budget.admitModularEncoder(width: width, height: height, channels: channels)
            let work = ScalarEncodingWork(budget: budget, writerByteLimit: limit)
            var pixels = [UInt16]()
            for i in 0..<n { pixels.append(UInt16((i * 71 + (i / width) * 37) & 65535)) }
            let encoded = try ScalarEncodingWork.$current.withValue(work) {
                if channels == 1 {
                    return try SpecModularEncoder.encodeGrayscale16(width: width, height: height,
                        bitsPerSample: 16, pixels: pixels, effort: effort)
                }
                return try SpecModularEncoder.encodeRGBA16(width: width, height: height,
                    bitsPerSample: 16, r: pixels, g: pixels, b: pixels, a: pixels, effort: effort)
            }
            try encoded.write(to: URL(fileURLWithPath: args[7]))
            report["status"] = "success"; report["encodedBytes"] = encoded.count
        } catch ScalarModularError.resourceLimit { report["status"] = "resourceLimit" }
        catch { report["status"] = "error"; report["error"] = String(describing: error) }
        report["reservedWorkspace"] = budget.reservedWorkspaceBytes
        let data = try JSONSerialization.data(withJSONObject: report, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}
