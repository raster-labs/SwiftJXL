from pathlib import Path
import json
w=Path(__file__).resolve().parent;out=w.parent.parent/'outputs'
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
d=json.loads((out/'modular-effort-budget-qualification.json').read_text())
p=repo/'Documentation/Engineering/Migration/MODULAR_EFFORT_BUDGET.md';s=p.read_text()
old='Local qualification is in progress. Exact commands, source hashes, regression results, independent decoding and controlled performance results will be recorded before publication.'
text='''Debug and release each pass 40 declarations / 249 argument cases. Address Sanitizer and Thread Sanitizer each pass the four affected higher-effort suites: 18 declarations / 123 cases. All final configurations use the same 181 source/test hashes, with zero failures, skips or sanitizer diagnostics. The final learner fixture has uneven equal-property runs crossing 1,024-sample blocks. Tests cover exact and one-byte-under cumulative admission, aggregate memory rejection, checked overflow, stable sorting at run boundaries, and cancellation/resource failures injected throughout both learners.

The 54 small candidate streams match PR27 bytes and decode every sample exactly through independent `djxl`. Seven larger/control cases are independently decoded on both sides (14 decodes), also with identical bytes. Every timed output matches its independently decoded hash. Forty-two separate old/new budget comparisons cover seven shapes, efforts 7/9 and one/two/eight workers: ample-budget outputs match, while every candidate rejects the old incomplete allowance with `resourceLimit` and every baseline accepts it. The candidate reservations range from about 22 MiB to 1,100 MiB under explicit larger trial limits; these are ledger charges, not measured allocation.

See [qualification index](Evidence/ModularEffortBudget/qualification.json), [raw evidence](Evidence/ModularEffortBudget/raw-evidence.zip), [regression tests](../../../Tests/SwiftJXLCoreTests/ModularEffortBudgetTests.swift) and [synthetic fixture provenance](../../../Tests/SwiftJXLCoreTests/Fixtures/Modular/Effort/provenance.json).

## Controlled performance and open trade-off

The release probe compares exact PR27 with this implementation on local macOS arm64 / Swift 6.4, using five warm-ups and ten timed encodes per block. Each comparison interleaves two blocks per implementation (20 samples per side); the repeat reverses the order. Thermal state is nominal in every recorded block. No agent-owned build, test, oracle or policy work overlaps timing. The internal probe is serial and has no operation-budget context; budget enforcement is qualified separately. Raw samples, median/p95/spread, throughput, size, process RSS and hashes are retained; peak algorithm workspace, allocation/copy counts and concurrent steady state are not measured.

| Case (effort) | Median latency change, first / repeat | Process peak RSS MiB, baseline → candidate, first / repeat |
| --- | --- | --- |
'''
for i,r in enumerate(d['comparisons'][0]['cases']):
    a=r['summaries'];b=d['comparisons'][1]['cases'][i]['summaries']
    def rss(x):return f"{x['baseline']['processPeakRSSBytes']/1024**2:.2f} → {x['candidate']['processPeakRSSBytes']/1024**2:.2f}"
    text+=f"| {r['name']} ({r['effort']}) | {a['medianChangePercent']:+.2f}% / {b['medianChangePercent']:+.2f}% | {rss(a)} / {rss(b)} |\n"
text+='''
The first bounded-sort implementation reproduced approximately 8–11% tree-case overhead. The retained investigation moved checkpoint calls outside tight merge, radix, histogram, packing and entropy-sweep element loops while retaining at-most-1,024-element blocks. This reduced the cost, but all four final tree-learning cases still exceed the 5% median-latency investigation threshold in both comparisons. The effort-7 activity-grey case also shows a repeated process peak RSS increase of about 5.5%; the stable merge uses an admitted full-length scratch array, although process RSS does not isolate allocator-level causation. Other larger RSS excursions do not repeat in both orders. Effort 3 has no repeatable latency or RSS regression. Encoded sizes and bytes are unchanged throughout.

**The PERF-03 trade-off remains open for review.** Bounded cancellation and complete component admission are the intended safety benefit; the measured internal higher-effort cost is explicit. This draft does not waive the performance gate, accept a new release baseline or establish stable-release readiness. The superseded sources, prior successful tests and all diagnostic/interleaved measurements remain in the archive.
'''
assert old in s;s=s.replace(old,text,1);p.write_text(s)
p=repo/'HISTORY.md';s=p.read_text();anchor='# History and provenance — SwiftJXL\n\n';entry='''## Higher-effort Modular admission and cancellation — 14 October 2026

Add cumulative reservations for collection, candidate routing/costing, selected emission and capped learning on top of the caller's effort-3 admission. Stable bounded sorting and checkpointed learner blocks preserve the scoped byte output while exposing resource/cancellation failures. Final debug/release pass 40 declarations / 249 cases; focused ASan/TSan pass 18 / 123. Fifty-four small streams and fourteen larger/control baseline/candidate streams independently decode exactly, and 42 old/new worker-budget comparisons reproduce the accounting repair. Repeated higher-effort tree latency still rises roughly 6–7% after investigation, and activity-grey process RSS rises about 5.5%; those safety/performance trade-offs remain open under PERF-03. Public effort stays 3 and Milestone 4 is incomplete. See [evidence and remaining gates](Documentation/Engineering/Migration/MODULAR_EFFORT_BUDGET.md).

''';assert anchor in s;s=s.replace(anchor,anchor+entry,1);p.write_text(s)
print('Updated qualification document and history')
