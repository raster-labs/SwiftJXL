// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Raster-Lab.
// Adapted from JXLSwift 57e81cb9e2411d1efac435b429a306a031744c1e, Sources/JXLSwift/Codestream/ImageMetadata.swift.
// ImageMetadata — top-level codestream-header structure that follows
// the SizeHeader.
//
// ISO/IEC 18181-1 §C.3.3. Encodes the image's bit depth, color
// encoding, alpha / extra-channel structure, animation flags, and
// optional preview / intrinsic-size hints.
//
// Layout (per spec):
//   all_default : 1 bit
//   if !all_default:
//     extra_fields : 1 bit
//     if extra_fields:
//       orientation       u(3)         // EXIF-style 1..8 (stored as 0..7)
//       intrinsic_size_present : 1 bit
//       if intrinsic_size_present: SizeHeader
//       preview_present : 1 bit
//       if preview_present: PreviewHeader
//       animation_present : 1 bit
//       if animation_present: AnimationHeader
//     bit_depth : BitDepth
//     modular_16bit_buffer_sufficient : 1 bit
//     num_extra_channels : U32(0, 1, 2, 3+u(4))
//     extra_channel_info : ExtraChannelInfo[num_extra_channels]
//     xyb_encoded : 1 bit
//     color_encoding : ColorEncoding
//     // intensity_target / tone_mapping fields...
//
// We don't yet implement the optional preview / animation header
// sub-structures or the tone-mapping fields beyond skipping them; they
// throw `NotYetImplemented` if encountered. For the dominant medical-
// imaging case (uncompressed monochrome / RGB stills) we cover every
// branch needed.

import Foundation

package struct PreviewHeader: Sendable, Equatable {
    package let xsize: UInt32
    package let ysize: UInt32
}

package struct AnimationHeader: Sendable, Equatable {
    package let tpsNumerator: UInt32
    package let tpsDenominator: UInt32
    package let numLoops: UInt32
    package let haveTimecodes: Bool
}

package struct ImageMetadata: Sendable {
    package let allDefault: Bool
    package let orientation: UInt32        // 1..8 (EXIF), default 1
    package let intrinsicSize: SizeHeader?
    package let preview: PreviewHeader?
    package let animation: AnimationHeader?
    package let bitDepth: BitDepth
    package let modular16BitBufferSufficient: Bool
    package let extraChannels: [ExtraChannelInfo]
    package let xybEncoded: Bool
    package let colorEncoding: ColorEncoding
    /// Intensity target (cd/m²) — for HDR.
    package let intensityTarget: Float
    /// Min nits of the source.
    package let minNits: Float
    /// Tone-mapping relative-to-max-display.
    package let relativeToMaxDisplay: Bool
    package let linearBelow: Float

    /// Default-everything image metadata (8-bit sRGB RGB, no alpha,
    /// no animation, no preview).
    package static let `default` = ImageMetadata(
        allDefault: true,
        orientation: 1,
        intrinsicSize: nil,
        preview: nil,
        animation: nil,
        bitDepth: .standard,
        modular16BitBufferSufficient: true,
        extraChannels: [],
        xybEncoded: true,
        colorEncoding: .srgb,
        intensityTarget: 255.0,
        minNits: 0.0,
        relativeToMaxDisplay: false,
        linearBelow: 0.0
    )

    package init(
        allDefault: Bool, orientation: UInt32,
        intrinsicSize: SizeHeader?, preview: PreviewHeader?,
        animation: AnimationHeader?, bitDepth: BitDepth,
        modular16BitBufferSufficient: Bool,
        extraChannels: [ExtraChannelInfo], xybEncoded: Bool,
        colorEncoding: ColorEncoding,
        intensityTarget: Float, minNits: Float,
        relativeToMaxDisplay: Bool, linearBelow: Float
    ) {
        self.allDefault = allDefault
        self.orientation = orientation
        self.intrinsicSize = intrinsicSize
        self.preview = preview
        self.animation = animation
        self.bitDepth = bitDepth
        self.modular16BitBufferSufficient = modular16BitBufferSufficient
        self.extraChannels = extraChannels
        self.xybEncoded = xybEncoded
        self.colorEncoding = colorEncoding
        self.intensityTarget = intensityTarget
        self.minNits = minNits
        self.relativeToMaxDisplay = relativeToMaxDisplay
        self.linearBelow = linearBelow
    }

    /// Number of channels including extras.
    package var totalChannels: Int {
        let colorN: Int
        switch colorEncoding.colorSpace {
        case .grayscale: colorN = 1
        default:         colorN = 3
        }
        return colorN + extraChannels.count
    }

    /// True if any extra channel is alpha.
    package var hasAlpha: Bool {
        extraChannels.contains { $0.type == .alpha }
    }

    package static func read(from r: inout BitReader) throws -> ImageMetadata {
        let allDefault = try r.readBit()
        if allDefault {
            return .default
        }

        var orientation: UInt32 = 1
        var intrinsicSize: SizeHeader? = nil
        var preview: PreviewHeader? = nil
        var animation: AnimationHeader? = nil

        let extraFields = try r.readBit()
        if extraFields {
            // orientation: 3 bits, encoded as (orientation - 1).
            orientation = (try r.read(bits: 3)) + 1

            let hasIntrinsic = try r.readBit()
            if hasIntrinsic {
                intrinsicSize = try SizeHeader.read(from: &r)
            }
            let hasPreview = try r.readBit()
            if hasPreview {
                // Spec uses a SizeHeader-like structure; for now we read
                // and stash xsize/ysize the same way.
                let s = try SizeHeader.read(from: &r)
                preview = PreviewHeader(xsize: s.xsize, ysize: s.ysize)
            }
            let hasAnim = try r.readBit()
            if hasAnim {
                let tpsNum = try r.readU32((
                    .literal(100), .literal(1000),
                    .offset(constant: 1, extraBits: 10),
                    .offset(constant: 1, extraBits: 30)
                ))
                let tpsDen = try r.readU32((
                    .literal(1), .literal(1001),
                    .offset(constant: 1, extraBits: 8),
                    .offset(constant: 1, extraBits: 10)
                ))
                let numLoops = try r.readU32((
                    .literal(0), .offset(constant: 0, extraBits: 3),
                    .offset(constant: 0, extraBits: 16),
                    .offset(constant: 0, extraBits: 32)
                ))
                let haveTC = try r.readBit()
                animation = AnimationHeader(
                    tpsNumerator: tpsNum, tpsDenominator: tpsDen,
                    numLoops: numLoops, haveTimecodes: haveTC
                )
            }
        }

        let bitDepth = try BitDepth.read(from: &r)
        let modular16 = try r.readBit()
        let numExtra = try r.readU32((
            .literal(0), .literal(1),
            .offset(constant: 2, extraBits: 4),
            .offset(constant: 1, extraBits: 12)
        ))
        if r.scalarProfile && numExtra != 0 { throw ScalarModularError.unsupportedProfile }
        if numExtra > 0 {
            try r.budget?.reserveWorkspace(Int(numExtra) * 2 * MemoryLayout<ExtraChannelInfo>.stride + 128)
        }
        var extras: [ExtraChannelInfo] = []
        extras.reserveCapacity(Int(numExtra))
        for _ in 0..<Int(numExtra) {
            extras.append(try ExtraChannelInfo.read(from: &r))
        }

        let xybEncoded = try r.readBit()
        let colorEncoding = try ColorEncoding.read(from: &r)

        // Tone-mapping fields. Per spec §C.3.6:
        //   intensity_target_default_present : 1 bit (default 255 cd/m^2)
        //   if !default: f16 intensity target ... we approximate by
        //   reading the spec's u(16) field and decoding as half-float.
        var intensity: Float = 255.0
        var minNits: Float = 0.0
        var rel: Bool = false
        var linBelow: Float = 0.0
        if extraFields {
            // Tone-mapping is encoded only when extra_fields = true.
            let toneDefault = try r.readBit()
            if !toneDefault {
                let intensityRaw = try r.read(bits: 16)
                intensity = halfToFloat(UInt16(intensityRaw))
                let minRaw = try r.read(bits: 16)
                minNits = halfToFloat(UInt16(minRaw))
                rel = try r.readBit()
                let linRaw = try r.read(bits: 16)
                linBelow = halfToFloat(UInt16(linRaw))
            }
        }

        // Extensions bitfield — `BeginExtensions` reads a U64 directly
        // (libjxl fields.h `VisitorBase::BeginExtensions` =
        // `U64(0, &extensions)`). U64=0 takes only the 2-bit selector
        // "00", so the no-extensions case stays compact. We don't yet
        // decode any extension payloads — the per-extension U64 size
        // fields would let a real implementation skip past unknown
        // extensions, which the current parser relies on no
        // codestreams using.
        guard try r.readU64() == 0 else { throw BitstreamError.malformedValue("Unsupported extension fields") }

        return ImageMetadata(
            allDefault: false,
            orientation: orientation,
            intrinsicSize: intrinsicSize,
            preview: preview,
            animation: animation,
            bitDepth: bitDepth,
            modular16BitBufferSufficient: modular16,
            extraChannels: extras,
            xybEncoded: xybEncoded,
            colorEncoding: colorEncoding,
            intensityTarget: intensity,
            minNits: minNits,
            relativeToMaxDisplay: rel,
            linearBelow: linBelow
        )
    }
}

extension ImageMetadata {

    /// Write an `ImageMetadata` to a bit writer. Symmetric inverse of
    /// `read(from:)` for the cases this parser supports.
    ///
    /// Currently writes:
    ///   • `all_default = true` (single bit) when every field matches
    ///     the spec defaults.
    ///   • Otherwise the full layout, with `extra_fields` set whenever
    ///     orientation, intrinsicSize, preview, animation, or tone
    ///     mapping deviate from defaults.
    ///
    /// Limitations: extension fields (the optional U64 + payload at the
    /// end of the metadata block) are not written — the writer always
    /// emits "no extensions". This matches the dominant case for
    /// medical imaging.
    package func write(to w: inout BitWriter) throws {
        if allDefault && isAllDefault {
            w.writeBit(true)
            return
        }
        w.writeBit(false)

        let needsExtraFields = needsExtraFieldsBranch
        w.writeBit(needsExtraFields)
        if needsExtraFields {
            // orientation - 1, 3 bits.
            w.write(bits: 3, value: orientation - 1)
            w.writeBit(intrinsicSize != nil)
            if let i = intrinsicSize {
                try i.write(to: &w)
            }
            w.writeBit(preview != nil)
            if let p = preview {
                try SizeHeader(xsize: p.xsize, ysize: p.ysize).write(to: &w)
            }
            w.writeBit(animation != nil)
            if let a = animation {
                try w.writeU32(a.tpsNumerator, distributions: (
                    .literal(100), .literal(1000),
                    .offset(constant: 1, extraBits: 10),
                    .offset(constant: 1, extraBits: 30)
                ))
                try w.writeU32(a.tpsDenominator, distributions: (
                    .literal(1), .literal(1001),
                    .offset(constant: 1, extraBits: 8),
                    .offset(constant: 1, extraBits: 10)
                ))
                try w.writeU32(a.numLoops, distributions: (
                    .literal(0), .offset(constant: 0, extraBits: 3),
                    .offset(constant: 0, extraBits: 16),
                    .offset(constant: 0, extraBits: 32)
                ))
                w.writeBit(a.haveTimecodes)
            }
        }

        try bitDepth.write(to: &w)
        w.writeBit(modular16BitBufferSufficient)

        try w.writeU32(UInt32(extraChannels.count), distributions: (
            .literal(0), .literal(1),
            .offset(constant: 2, extraBits: 4),
            .offset(constant: 1, extraBits: 12)
        ))
        for ec in extraChannels {
            try ec.write(to: &w)
        }

        w.writeBit(xybEncoded)
        try colorEncoding.write(to: &w)

        if needsExtraFields {
            // Tone-mapping block.
            let toneIsDefault = (intensityTarget == 255.0 && minNits == 0.0
                && !relativeToMaxDisplay && linearBelow == 0.0)
            w.writeBit(toneIsDefault)
            if !toneIsDefault {
                w.write(bits: 16, value: UInt32(floatToHalf(intensityTarget)))
                w.write(bits: 16, value: UInt32(floatToHalf(minNits)))
                w.writeBit(relativeToMaxDisplay)
                w.write(bits: 16, value: UInt32(floatToHalf(linearBelow)))
            }
        }

        // No extensions — U64(0) emits the 2-bit selector "00".
        w.writeU64(0)
    }

    /// True when every field matches the spec defaults — what
    /// `all_default = 1` represents.
    var isAllDefault: Bool {
        orientation == 1 && intrinsicSize == nil && preview == nil
            && animation == nil
            && bitDepth.floatingPoint == false
            && bitDepth.bitsPerSample == 8
            && bitDepth.exponentBitsPerSample == 0
            && modular16BitBufferSufficient
            && extraChannels.isEmpty
            && xybEncoded
            && intensityTarget == 255.0
            && minNits == 0.0
            && !relativeToMaxDisplay
            && linearBelow == 0.0
    }

    /// True when the writer needs the `extra_fields = 1` branch.
    var needsExtraFieldsBranch: Bool {
        orientation != 1 || intrinsicSize != nil || preview != nil
            || animation != nil
            || intensityTarget != 255.0
            || minNits != 0.0
            || relativeToMaxDisplay
            || linearBelow != 0.0
    }
}

extension ColorEncoding {
    /// True iff this colour encoding is the spec default — sRGB,
    /// D65, sRGB primaries, sRGB transfer, Relative intent, no ICC,
    /// no custom white/primaries. The encoder emits a single
    /// `all_default = 1` bit when this holds (see §C.3.4).
    var isAllDefault: Bool {
        guard !useICC, colorSpace == .rgb,
              whitePoint == .d65, primaries == .srgb,
              renderingIntent == .relative,
              customWhite == nil, customPrimaries == nil else {
            return false
        }
        if case .srgb = transferFunction { return true }
        return false
    }

    package func write(to w: inout BitWriter) throws {
        // Per spec §C.3.4: ColorEncoding has its own all_default bit
        // (distinct from ImageMetadata's). Single-bit shortcut for
        // the spec-default sRGB case.
        if isAllDefault {
            w.writeBit(true)
            return
        }
        w.writeBit(false)
        w.writeBit(useICC)
        // ColorSpace via Enum() — see SpecIntegers.readEnum for the
        // distribution. Reachable values 0..81; named JXL values
        // 0=RGB, 1=Gray, 2=XYB, 3=Unknown.
        try w.writeEnum(colorSpace.rawValue)
        guard !useICC else { return }

        // Per-field skip flags match libjxl: XYB has implicit D65,
        // gray/XYB have no primaries. TF + rendering intent are always
        // emitted in the non-ICC branch.
        let implicitWhitePoint = (colorSpace == .xyb)
        let hasPrimaries = (colorSpace != .grayscale && colorSpace != .xyb)

        if !implicitWhitePoint {
            let wp = whitePoint ?? .d65
            try w.writeEnum(wp.rawValue)
            if wp == .custom, let cw = customWhite {
                try w.writeU32(cw.0, distributions: (.bits(19), .bits(19), .bits(20), .bits(21)))
                try w.writeU32(cw.1, distributions: (.bits(19), .bits(19), .bits(20), .bits(21)))
            }
        }

        if hasPrimaries {
            let prim = primaries ?? .srgb
            // Primaries — `Enum()`. Named: 1=sRGB, 2=custom,
            // 9=BT2100, 11=DCI-P3.
            try w.writeEnum(prim.rawValue)
            if prim == .custom, let cp = customPrimaries {
                func writeChrom(_ ch: (UInt32, UInt32)) throws {
                    try w.writeU32(ch.0, distributions: (.bits(19), .bits(19), .bits(20), .bits(21)))
                    try w.writeU32(ch.1, distributions: (.bits(19), .bits(19), .bits(20), .bits(21)))
                }
                try writeChrom(cp.0)
                try writeChrom(cp.1)
                try writeChrom(cp.2)
            }
        }

        // Transfer function. `have_gamma` u(1) flag, then either a
        // 24-bit gamma value or the TF as Enum() — covering all named
        // values 1=BT709, 2=Unknown, 8=Linear, 13=sRGB, 16=PQ,
        // 17=DCI, 18=HLG (the last two reach via `18+u(6)` and so
        // need the spec-correct Enum dist, not a custom 1+u(4) one).
        switch transferFunction {
        case .gamma(let g):
            w.writeBit(true)
            w.write(bits: 24, value: g)
        case .bt709:   w.writeBit(false); try w.writeEnum(1)
        case .unknown: w.writeBit(false); try w.writeEnum(2)
        case .linear:  w.writeBit(false); try w.writeEnum(8)
        case .srgb:    w.writeBit(false); try w.writeEnum(13)
        case .pq:      w.writeBit(false); try w.writeEnum(16)
        case .dci:     w.writeBit(false); try w.writeEnum(17)
        case .hlg:     w.writeBit(false); try w.writeEnum(18)
        }

        // Rendering intent — `Enum()` per spec.
        try w.writeEnum(renderingIntent.rawValue)
    }
}

extension ExtraChannelInfo {
    package func write(to w: inout BitWriter) throws {
        // We only emit the all_default = 1 case for default alpha
        // channels; otherwise emit the full structure.
        let isDefaultAlpha = (type == .alpha
            && bitDepth.bitsPerSample == 8 && !bitDepth.floatingPoint
            && dimShift == 0 && name.isEmpty && !alphaAssociated)
        if isDefaultAlpha {
            w.writeBit(true)
            return
        }
        w.writeBit(false)

        // Type as Enum: U32(0, 1, 2, 1+u(4))
        try w.writeU32(type.rawValue, distributions: (
            .literal(0), .literal(1), .literal(2),
            .offset(constant: 1, extraBits: 4)
        ))
        try bitDepth.write(to: &w)
        try w.writeU32(dimShift, distributions: (
            .literal(0), .literal(3), .literal(4),
            .offset(constant: 1, extraBits: 3)
        ))

        let nameBytes = Array(name.utf8)
        try w.writeU32(UInt32(nameBytes.count), distributions: (
            .literal(0),
            .offset(constant: 0, extraBits: 4),
            .offset(constant: 16, extraBits: 5),
            .offset(constant: 48, extraBits: 10)
        ))
        for b in nameBytes {
            w.write(bits: 8, value: UInt32(b))
        }

        switch type {
        case .alpha:
            w.writeBit(alphaAssociated)
        case .spotColor:
            // 4 × half-float (16-bit) RGBA values to match libjxl
            // image_metadata.cc.
            let s = spotColorRGBA ?? (0, 0, 0, 0)
            w.write(bits: 16, value: UInt32(floatToHalf(s.0)))
            w.write(bits: 16, value: UInt32(floatToHalf(s.1)))
            w.write(bits: 16, value: UInt32(floatToHalf(s.2)))
            w.write(bits: 16, value: UInt32(floatToHalf(s.3)))
        case .cfa:
            try w.writeU32(cfaChannel ?? 1, distributions: (
                .literal(1),
                .offset(constant: 0, extraBits: 2),
                .offset(constant: 3, extraBits: 4),
                .offset(constant: 19, extraBits: 8)
            ))
        default:
            break
        }
    }
}

/// IEEE-754 half-precision (binary16) → Float32. Used for tone-mapping
/// fields where the spec stores f16 in 16 bits.
func halfToFloat(_ h: UInt16) -> Float {
    let sign = UInt32(h & 0x8000) << 16
    let exp  = UInt32(h & 0x7C00) >> 10
    let frac = UInt32(h & 0x03FF)
    if exp == 0 {
        // Subnormal or zero.
        if frac == 0 {
            return Float(bitPattern: sign)
        }
        // Subnormal — shift to a normalised float32.
        var e: UInt32 = 1
        var f = frac
        while (f & 0x0400) == 0 {
            f <<= 1; e &+= 1
        }
        f &= 0x03FF
        let bits = sign | ((127 &- 15 &- e &+ 1) << 23) | (f << 13)
        return Float(bitPattern: bits)
    }
    if exp == 0x1F {
        // Inf or NaN.
        return Float(bitPattern: sign | 0x7F800000 | (frac << 13))
    }
    let bits = sign | ((exp &+ (127 &- 15)) << 23) | (frac << 13)
    return Float(bitPattern: bits)
}

/// IEEE-754 single-precision → half-precision. Truncating round-down for
/// the mantissa (sufficient for tone-mapping fields; full IEEE round-to-
/// nearest-even is not required by the spec).
func floatToHalf(_ f: Float) -> UInt16 {
    let bits = f.bitPattern
    let sign = UInt16((bits >> 16) & 0x8000)
    let exp32 = Int((bits >> 23) & 0xFF)
    let frac32 = bits & 0x007F_FFFF

    if exp32 == 0xFF {
        // Inf / NaN.
        let frac16 = frac32 != 0 ? UInt16(0x0200) : UInt16(0)
        return sign | 0x7C00 | frac16
    }
    let exp16 = exp32 - (127 - 15)
    if exp16 <= 0 {
        // Zero or subnormal — round to zero of right sign.
        return sign
    }
    if exp16 >= 31 {
        // Overflow → +/- infinity.
        return sign | 0x7C00
    }
    let exp16U = UInt16(exp16)
    let frac16 = UInt16((frac32 >> 13) & 0x03FF)
    return sign | (exp16U << 10) | frac16
}
