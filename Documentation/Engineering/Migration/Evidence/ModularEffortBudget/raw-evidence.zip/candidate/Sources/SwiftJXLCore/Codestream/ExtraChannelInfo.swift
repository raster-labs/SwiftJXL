// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Raster-Lab.
// Adapted from JXLSwift 57e81cb9e2411d1efac435b429a306a031744c1e, Sources/JXLSwift/Codestream/ExtraChannelInfo.swift.
// ExtraChannelInfo — declares per-extra-channel metadata.
//
// ISO/IEC 18181-1 §C.3.7. JXL supports up to 256 extra channels beyond
// the colour samples; common types are alpha, depth maps, thermal, and
// optional spot colours. Each ExtraChannelInfo records its semantic
// type, bit depth, dim shift (sub-sampled channels), and a name.

import Foundation

package enum ExtraChannelType: UInt32, Sendable, Equatable, CaseIterable {
    case alpha       = 0
    case depth       = 1
    case spotColor   = 2
    case selectionMask = 3
    case black       = 4    // CMYK black
    case cfa         = 5    // raw colour-filter-array
    case thermal     = 6
    case nonOptional = 7
    case optional    = 8

    package var isAlpha: Bool { self == .alpha }
}

package struct ExtraChannelInfo: Sendable {
    package let type: ExtraChannelType
    package let bitDepth: BitDepth
    /// The channel is sub-sampled by `2^dimShift` along each axis.
    package let dimShift: UInt32
    package let name: String
    /// True if the alpha channel is premultiplied (only meaningful when
    /// `type == .alpha`).
    package let alphaAssociated: Bool
    /// Spot-color RGBA when `type == .spotColor`.
    package let spotColorRGBA: (Float, Float, Float, Float)?
    /// CFA channel index when `type == .cfa`.
    package let cfaChannel: UInt32?

    package init(
        type: ExtraChannelType,
        bitDepth: BitDepth,
        dimShift: UInt32,
        name: String,
        alphaAssociated: Bool = false,
        spotColorRGBA: (Float, Float, Float, Float)? = nil,
        cfaChannel: UInt32? = nil
    ) {
        self.type = type
        self.bitDepth = bitDepth
        self.dimShift = dimShift
        self.name = name
        self.alphaAssociated = alphaAssociated
        self.spotColorRGBA = spotColorRGBA
        self.cfaChannel = cfaChannel
    }

    /// Read a single ExtraChannelInfo (§C.3.7).
    package static func read(from r: inout BitReader) throws -> ExtraChannelInfo {
        let allDefault = try r.readBit()
        if allDefault {
            return ExtraChannelInfo(
                type: .alpha,
                bitDepth: .standard,
                dimShift: 0,
                name: ""
            )
        }
        let typeRaw = try r.readEnum()
        let type = ExtraChannelType(rawValue: typeRaw) ?? .optional
        let bitDepth = try BitDepth.read(from: &r)
        // dim_shift distribution per libjxl image_metadata.cc
        // (`Val(0), Val(3), Val(4), BitsOffset(3, 1)`):
        let dimShift = try r.readU32((
            .literal(0), .literal(3), .literal(4),
            .offset(constant: 1, extraBits: 3)
        ))
        let nameLen = try r.readU32((
            .literal(0),
            .offset(constant: 0, extraBits: 4),
            .offset(constant: 16, extraBits: 5),
            .offset(constant: 48, extraBits: 10)
        ))
        if nameLen > 0 { try r.budget?.reserveWorkspace(Int(nameLen) * 3 + 128) }
        var nameBytes = [UInt8]()
        nameBytes.reserveCapacity(Int(nameLen))
        for _ in 0..<Int(nameLen) {
            nameBytes.append(UInt8(try r.read(bits: 8)))
        }
        guard let name = String(bytes: nameBytes, encoding: .utf8) else {
            throw BitstreamError.malformedValue("Invalid extra-channel name UTF-8")
        }

        var alphaAssociated = false
        var spotRGBA: (Float, Float, Float, Float)? = nil
        var cfaIdx: UInt32? = nil

        switch type {
        case .alpha:
            alphaAssociated = try r.readBit()
        case .spotColor:
            // 4 × half-float (16-bit) RGBA values per libjxl
            // image_metadata.cc — `visitor->F16(0, &c)` per channel.
            let rr = halfToFloat(UInt16(try r.read(bits: 16)))
            let gg = halfToFloat(UInt16(try r.read(bits: 16)))
            let bb = halfToFloat(UInt16(try r.read(bits: 16)))
            let aa = halfToFloat(UInt16(try r.read(bits: 16)))
            spotRGBA = (rr, gg, bb, aa)
        case .cfa:
            cfaIdx = try r.readU32((
                .literal(1), .offset(constant: 0, extraBits: 2),
                .offset(constant: 3, extraBits: 4),
                .offset(constant: 19, extraBits: 8)
            ))
        default:
            break
        }

        return ExtraChannelInfo(
            type: type, bitDepth: bitDepth, dimShift: dimShift,
            name: name, alphaAssociated: alphaAssociated,
            spotColorRGBA: spotRGBA, cfaChannel: cfaIdx
        )
    }
}
