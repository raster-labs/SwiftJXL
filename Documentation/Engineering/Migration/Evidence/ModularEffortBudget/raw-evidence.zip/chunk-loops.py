from pathlib import Path
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
p=repo/'Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift'
s=p.read_text();begin=s.index('    private static func radixSortInt64Prefix(');end=s.index('    /// Learn a greedy',begin)
part=s[begin:end]
# Keep checkpoint frequency and sequence, moving the throwing call outside
# the tight element loop so the compiler can optimise each bounded block.
for indent in ['                ','                    ','                    ']:
 old=indent+'for i in 0..<m {\n'+indent+'    if i & 1023 == 0 { try checkpoint() }\n'
 assert old in part
 start=part.index(old);bodyStart=start+len(old);depth=1;cursor=bodyStart
 while depth:
  if part[cursor]=='{':depth+=1
  if part[cursor]=='}':depth-=1
  cursor+=1
 body=part[bodyStart:cursor-1]
 assert body.endswith(indent)
 body=body[:-len(indent)]
 replacement=indent+'for blockStart in stride(from: 0, to: m, by: 1024) {\n'+indent+'    try checkpoint()\n'+indent+'    for i in blockStart..<min(blockStart + 1024, m) {\n'+''.join('    '+line+'\n' for line in body.splitlines())+indent+'    }\n'+indent+'}'
 part=part[:start]+replacement+part[cursor:]
s=s[:begin]+part+s[end:]
p.write_text(s)
p=repo/'Sources/SwiftJXLCore/Codec/ModularEffortWork.swift';s=p.read_text()
old='''                        for output in start..<end {
                            if output & 1023 == 0 { try checkpoint() }
                            // Choose left on equality, preserving the original
                            // order of equal properties and existing tie rules.
                            if right < end && (left == middle || less(source[right], source[left])) {
                                destination[output] = source[right]; right += 1
                            } else {
                                destination[output] = source[left]; left += 1
                            }
                        }
'''
new='''                        var blockStart = start
                        while blockStart < end {
                            try checkpoint()
                            let blockEnd = blockStart + min(run, end - blockStart)
                            for output in blockStart..<blockEnd {
                                // Choose left on equality, preserving the original
                                // order of equal properties and existing tie rules.
                                if right < end && (left == middle || less(source[right], source[left])) {
                                    destination[output] = source[right]; right += 1
                                } else {
                                    destination[output] = source[left]; left += 1
                                }
                            }
                            blockStart = blockEnd
                        }
'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
