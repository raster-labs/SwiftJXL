from pathlib import Path
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
p=repo/'Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift';s=p.read_text()
old='''            for (j, i) in node.idxs.enumerated() {
                if j & 1023 == 0 { try checkpoint() }
                nodeHist[tokBucket[i]] += 1
            }
'''
new='''            for blockStart in stride(from: 0, to: m, by: 1024) {
                try checkpoint()
                for j in blockStart..<min(blockStart + 1024, m) {
                    nodeHist[tokBucket[node.idxs[j]]] += 1
                }
            }
'''
assert old in s;s=s.replace(old,new,1)
old='''                for (i, idx) in node.idxs.enumerated() {
                    if i & 1023 == 0 { try checkpoint() }
                    packedBuf[i] = (Int64(propsFlat[idx * propCount + k]) << 16)
                        | Int64(tokBucket[idx])
                }
'''
new='''                for blockStart in stride(from: 0, to: m, by: 1024) {
                    try checkpoint()
                    for i in blockStart..<min(blockStart + 1024, m) {
                        let idx = node.idxs[i]
                        packedBuf[i] = (Int64(propsFlat[idx * propCount + k]) << 16)
                            | Int64(tokBucket[idx])
                    }
                }
'''
assert old in s;s=s.replace(old,new,1)
old='''                while j < m {
                    let v = packedBuf[j] >> 16
                    while j < m && (packedBuf[j] >> 16) == v {
                        if j & 1023 == 0 { try checkpoint() }
                        let tk = Int(packedBuf[j] & 0xffff)
                        hiS -= term(hi[tk]); hi[tk] -= 1; hiS += term(hi[tk]); hiTot -= 1
                        loS -= term(loBuf[tk]); loBuf[tk] += 1; loS += term(loBuf[tk]); loTot += 1
                        j += 1
                    }
                    if hiTot > 0 {
                        let loCost = loTot <= 1 ? 0 : clogc[loTot] - loS
                        let hiCost = clogc[hiTot] - hiS
                        let gain = nodeCost - (loCost + hiCost)
                        if gain > node.bestGain {
                            node.bestGain = gain; node.bestK = k
                            node.bestSplit = Int32(v)
                        }
                    }
                }
'''
new='''                while j < m {
                    try checkpoint()
                    let blockEnd = min(j + 1024, m)
                    while j < blockEnd {
                        let v = packedBuf[j] >> 16
                        let tk = Int(packedBuf[j] & 0xffff)
                        hiS -= term(hi[tk]); hi[tk] -= 1; hiS += term(hi[tk]); hiTot -= 1
                        loS -= term(loBuf[tk]); loBuf[tk] += 1; loS += term(loBuf[tk]); loTot += 1
                        j += 1
                        // A block may end inside equal properties. Evaluate
                        // only their actual boundary, preserving sums/ties.
                        if hiTot > 0 && (packedBuf[j] >> 16) != v {
                            let loCost = loTot <= 1 ? 0 : clogc[loTot] - loS
                            let hiCost = clogc[hiTot] - hiS
                            let gain = nodeCost - (loCost + hiCost)
                            if gain > node.bestGain {
                                node.bestGain = gain; node.bestK = k
                                node.bestSplit = Int32(v)
                            }
                        }
                    }
                }
'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
