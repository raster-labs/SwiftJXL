from pathlib import Path
import json,subprocess,hashlib,sys,time,os
w=Path(__file__).resolve().parent
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
name=sys.argv[1];out=w/name;out.mkdir(exist_ok=True)
base='ffeeef7e9f8807a6ad575ba416842df984bf8283'
sources=[];hashes={}
paths=[repo / rel for rel in subprocess.check_output(['git','ls-tree','-r','--name-only',base,'Sources/SwiftJXLCore'],cwd=repo,text=True).splitlines() if rel.endswith('.swift')] if name=='baseline' else sorted((repo/'Sources/SwiftJXLCore').rglob('*.swift'))
for p in paths:
 rel=str(p.relative_to(repo));data=subprocess.check_output(['git','show',base+':'+rel],cwd=repo) if name=='baseline' else p.read_bytes()
 dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);sources.append(str(dest));hashes[rel]=hashlib.sha256(data).hexdigest()
flags=['-O','-g','-whole-module-optimization','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0','-module-cache-path',str(w/'cache'),'-package-name','SwiftJXL']
cmd=['xcrun','swiftc',*flags,'-parse-as-library','-module-name','SwiftJXLCore','-emit-module','-emit-module-path',str(out/'SwiftJXLCore.swiftmodule'),'-emit-library','-static',*sources,'-o',str(out/'libSwiftJXLCore.a')]
env=dict(os.environ,SWIFT_DETERMINISTIC_HASHING='1');start=time.monotonic()
with (out/'build.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
assert r.returncode==0,(out/'build.log').read_text()[-3500:]
link=['xcrun','swiftc',*flags,'-parse-as-library','-I',str(out),str(w/'probe.swift'),str(out/'libSwiftJXLCore.a'),'-o',str(out/'probe')]
with (out/'link.log').open('w') as log:r=subprocess.run(link,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(out/'link.log').read_text()[-3500:]
report={'base':base,'name':name,'command':cmd,'linkCommand':link,'exit':0,'seconds':time.monotonic()-start,'sourceHashes':hashes,'binarySHA256':hashlib.sha256((out/'probe').read_bytes()).hexdigest(),'probeSHA256':hashlib.sha256((w/'probe.swift').read_bytes()).hexdigest(),'compiler':subprocess.check_output(['xcrun','swiftc','--version'],text=True),'os':subprocess.check_output(['sw_vers'],text=True)}
(out/'build.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k in ['base','name','seconds','exit','compiler']}))
