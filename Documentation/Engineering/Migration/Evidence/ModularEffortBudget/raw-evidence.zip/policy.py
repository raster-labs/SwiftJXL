from pathlib import Path
import hashlib,json,subprocess
w=Path(__file__).resolve().parent
out=w/'policy';out.mkdir(exist_ok=True)
report={'base':'ffeeef7e9f8807a6ad575ba416842df984bf8283','cases':[],'scope':'Cumulative reservation accounting, not allocator/RSS measurement; explicit larger trial limits.'}
for name in ['baseline','candidate']:
    lib=w/name
    cmd=['xcrun','swiftc','-O','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0','-module-cache-path',str(w/'cache'),'-package-name','SwiftJXL','-parse-as-library','-I',str(lib),str(w/'policy.swift'),str(lib/'libSwiftJXLCore.a'),'-o',str(out/name)]
    r=subprocess.run(cmd,capture_output=True,text=True);(out/(name+'-build.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
    report[name+'Build']=cmd
def run(name,width,height,channels,effort,workers,limit,label):
    stream=out/(label+'-'+name+'.jxl')
    cmd=[str(out/name),*map(str,[width,height,channels,effort,workers,limit]),str(stream)]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
    (out/(label+'-'+name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
    d=json.loads(r.stdout);d['command']=cmd;d['exit']=r.returncode
    if d['status']=='success':d['codestreamSHA256']=hashlib.sha256(stream.read_bytes()).hexdigest()
    return d
for width,height,channels in [(31,9,1),(31,9,4),(513,9,1),(513,9,4),(512,511,1),(256,499,4),(1025,499,1)]:
 for effort in [7,9]:
  for workers in [1,2,8]:
    stem=f'{width}x{height}-c{channels}-e{effort}-w{workers}'
    old=run('baseline',width,height,channels,effort,workers,3*1024**3,stem+'-ample')
    new=run('candidate',width,height,channels,effort,workers,3*1024**3,stem+'-ample')
    assert old['status']==new['status']=='success',(old,new)
    assert old['codestreamSHA256']==new['codestreamSHA256']
    old_limit=old['reservedWorkspace']
    old_tight=run('baseline',width,height,channels,effort,workers,old_limit,stem+'-old-limit')
    new_tight=run('candidate',width,height,channels,effort,workers,old_limit,stem+'-old-limit')
    assert old_tight['status']=='success' and new_tight['status']=='resourceLimit',(old_tight,new_tight)
    report['cases'].append({'name':stem,'baseline':old,'candidate':new,'oldAtBaselineLimit':old_tight,'newAtBaselineLimit':new_tight})
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(stem,old_limit,new['reservedWorkspace'],flush=True)
report['status']='passed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
