from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

w = Path(__file__).resolve().parent
out = w.parent.parent / 'outputs'
repo = Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
def read(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, d): p.write_text(json.dumps(d, indent=2) + '\n')
hashes = {str(p.relative_to(repo)): digest(p) for folder in ['Sources', 'Tests'] for p in (repo/folder).rglob('*.swift')}
validation = []
for config in ['debug', 'release', 'asan', 'tsan']:
    d = read(w/f'sampling-{config}.json')
    assert d['exit'] == 0 and d.pop('sourceHashes') == hashes
    assert d['xml']['failures'] == d['xml']['errors'] == d['xml']['skips'] == 0
    log = (w/f'sampling-{config}.log').read_text()
    cases = [int(n) for n in re.findall(r'✔ Test [^\n]+ with (\d+) test cases passed', log)]
    d['argumentCases'] = d['xml']['declarations'] - len(cases) + sum(cases)
    assert not re.search(r'(ERROR: AddressSanitizer|WARNING: ThreadSanitizer|SUMMARY: (?:AddressSanitizer|ThreadSanitizer))', log)
    validation.append(d)
build = read(w/'candidate/build.json')
assert all(hashes[p] == h for p, h in build['sourceHashes'].items())
assert digest(w/'candidate/probe') == build['binarySHA256']
reuse = read(w/'baseline-reuse.json')
for name, d in reuse.items():
    assert d['matchedCoreFiles'] == 98
    assert digest(w/name/'probe') == d['binarySHA256']
    assert d['priorBuild']['probeSHA256'] == build['probeSHA256'] == digest(w/'probe.swift')
    for path, h in d['priorBuild']['sourceHashes'].items():
        source = subprocess.check_output(['git', 'show', d['head']+':'+path], cwd=repo)
        assert hashlib.sha256(source).hexdigest() == h
small = read(w/'candidate-preflight/report.json')
large = read(w/'large-preflight/report.json')
policy = read(w/'policy/report.json')
assert small['status'] == large['status'] == policy['status'] == 'passed'
assert len(small['cases']) == 54 and len(large['cases']) == 7 and len(policy['cases']) == 42
comparisons = []
for label in ['initial', 'repeat']:
    d = read(w/label/'report.json')
    assert d['status'] == 'completed' and len(d['cases']) == 7
    assert d['binaries']['candidate'] == build['binarySHA256']
    for row in d['cases']:
        independent = next(r for r in large['cases'] if r['name'] == row['name'])
        for run in row['runs']:
            name = run['implementation']
            if name != 'candidate': assert d['binaries'][name] == reuse[name]['binarySHA256']
            oracle = next(r for r in independent['runs'] if r['implementation'] == ('baseline' if name == 'pre-safety' else name))
            assert run['codestreamSHA256'] == oracle['sha256']
        s = row['summaries']
        for reference in ['baseline', 'pre-safety']:
            s[reference+'RSSChangePercent'] = (s['candidate']['processPeakRSSBytes']/s[reference]['processPeakRSSBytes']-1)*100
    comparisons.append({'label': label, 'order': d['order'], 'cases': [{k:v for k,v in r.items() if k != 'runs'} for r in d['cases']]})
regressions = []
for i, row in enumerate(comparisons[0]['cases']):
    for reference, latencyKey in [('baseline','medianChangePercent'), ('pre-safety','preSafetyMedianChangePercent')]:
        latency = [c['cases'][i]['summaries'][latencyKey] for c in comparisons]
        rss = [c['cases'][i]['summaries'][reference+'RSSChangePercent'] for c in comparisons]
        if all(x > 5 for x in latency) or all(x > 5 for x in rss):
            regressions.append({'case':row['name'], 'reference':reference, 'latencyChangePercent':latency, 'peakRSSChangePercent':rss})
prior = read(out/'modular-effort-budget-qualification.json')
contracts = prior['commonContractHashes']
assert all(digest(repo/p) == h for p,h in contracts.items())
history = read(w/'candidate-allocator-history/report.json')
diagnosticBuild = read(w/'build-candidate-diagnostic.json')['candidate']
assert history['status'] == 'passed' and len(history['runs']) == 6
assert diagnosticBuild['librarySHA256'] == digest(w/'candidate/libSwiftJXLCore.a')
diagnostics = []
for run in history['runs']:
    if run['implementation'] == 'candidate':
        assert run['binarySHA256'] == diagnosticBuild['probeSHA256']
    h = run['result']['memoryHistory']
    diagnostics.append({'implementation':run['implementation'],
        'firstInUseBytes':h[1]['bytesInUse'], 'finalInUseBytes':h[-1]['bytesInUse'],
        'firstReservedBytes':h[1]['reservedBytes'], 'finalReservedBytes':h[-1]['reservedBytes'],
        'peakRSSBytes':h[-1]['peakRSSBytes'], 'codestreamSHA256':run['codestreamSHA256']})
report = {
    'asOfUTC':datetime.now(timezone.utc).isoformat(),
    'status':'Scoped local qualification; hosted and broader Milestone 4 gates remain open.',
    'branch':'codex/swiftjxl-modular-grey-memory',
    'base':'f8083c901fdb784111c7f296517c45d27a61db74',
    'targetBaseBranch':'codex/swiftjxl-modular-learner-performance',
    'preSafetyReference':'ffeeef7e9f8807a6ad575ba416842df984bf8283',
    'contract':'0.10.0', 'predecessorPin':'57e81cb9e2411d1efac435b429a306a031744c1e',
    'change':[
        'Replace per-node child index arrays with ranges in one operation-local index owner.',
        'Partition each selected leaf in place, eliminating child allocation, counting passes and separate partition scratch.',
        'Preserve the property/token multiset, deterministic split selection and original-index context mapping; encounter order is private and not observable.',
        'Keep cancellation checks in blocks of at most 1024 indices and all buffer pointers inside synchronous borrows.',
        'Preserve cumulative workspace admission, policy errors, public effort 3 and tested codestream bytes.'
    ],
    'validation':validation,
    'independentOracle':{'tool':'djxl 0.12.0', 'smallCases':54, 'largerControlCases':7, 'largerIndependentDecodes':14,
        'result':'All decoded samples exact. Tested codestream bytes unchanged against PR29; timed streams also match PR27.'},
    'policy':{'cases':42, 'workers':[1,2,8], 'efforts':[7,9], 'result':'Identical ample-budget output and cumulative reservations; PR29 and candidate both reject one byte below the reservation. Unit tests cover exact and aggregate limits.', 'evidence':'policy/report.json'},
    'comparisons':comparisons,
    'performanceGate':{'status':'Repeated scoped threshold breach remains open.' if regressions else 'No repeated final scoped threshold breach; broader qualification remains open.',
        'confirmedOverFivePercent':regressions, 'scope':'Seven serial synthetic core cases against PR29 and PR27. No release-baseline waiver or universal memory claim.'},
    'measurementProtocol':{'warmupsPerBlock':5, 'timedIterationsPerBlock':10,
        'timedIterationsPerImplementationPerCasePerComparison':20, 'noConcurrentLocalQualificationJobs':True, 'evidence':'measurement-window.json'},
    'allocatorDiagnostic':{'scope':'Serial 30-iteration diagnostic after the initial encode and five warm-ups; timings excluded. Zone totals at encode boundaries are not peak live algorithm workspace.',
        'runs':diagnostics, 'highWaterTouchedBytes':'Unavailable: malloc statistics returned zero; not treated as a measured zero peak.',
        'evidence':'candidate-allocator-history/report.json'},
    'investigation':[
        'Initial PR27/28/29 endpoint traces found similar live payload after encoding but variable reserved memory and process peaks.',
        'Instrumented PR27/29 stage boundaries associated a later PR29 RSS increase with greedy learning. This was diagnostic correlation, not allocator causality proof.',
        'The retained two-buffer experiment did not show a reliable memory improvement over PR29. The final implementation uses a single owner.'
    ],
    'sourceAndTestHashes':hashes, 'commonContractHashes':contracts,
    'baselineReuse':{k:{a:b for a,b in v.items() if a!='priorBuild'} for k,v in reuse.items()},
    'environment':{'compiler':build['compiler'], 'os':build['os'], 'target':'arm64-apple-macos26.0'},
    'limitations':[
        'Public API and CLI effort remain 3. Higher public effort, broader profiles/precision/corpus and production readiness are not qualified.',
        'Process RSS and allocator reservations depend on allocation history. All earlier breaches and superseded experiments are retained; endpoint live bytes are not peak algorithm workspace.',
        'Admission retains the conservative PR28 formula even though child index arrays are eliminated; this does not relax resource limits.',
        'Checkpointed loops do not provide real-time interruption of allocation, COW, runtime work or scheduling.',
        'Serial internal timing and worker-budget checks do not establish concurrent steady-state allocator or copy telemetry.',
        'Local Swift 6.4 arm64 checks do not replace hosted Swift 6.2/Linux or minimum-OS/physical-device runtime qualification.',
        'Broader Modular predecessor performance, JPEG, VarDCT ARM-reference differences, animation and feature reconciliation remain open. Milestone 4 is incomplete; JXLSwift remains the production route.'
    ]
}
write(out/'modular-grey-memory-qualification.json', report)
review = {'asOfUTC':report['asOfUTC'], 'reviewer':'Current coding agent; source/diff review, not independent GitHub approval',
    'base':report['base'], 'sourceAndTestHashes':hashes, 'correctnessFindings':[], 'qualificationFindings':regressions,
    'scope':[
        'Ranges remain disjoint and cover the original indices; middle never exceeds the current position, and swaps preserve the selected leaf multiset.',
        'Integer histograms and sorted packed property/token values are independent of private leaf encounter order. Tie rules and floating-point sweep order remain unchanged.',
        'The original-index context map is independently checked by decoder tree walking with uneven permuted populations and 2/8/32 leaves.',
        'One initialised array owns all indices. Synchronous mutable borrow does not escape; cancellation unwinds only private storage, leaving caller properties/tokens intact.',
        'Final source hashes, sanitizers, independent samples/bytes, budget boundaries and repeated comparisons verified.'
    ], 'limitations':report['limitations']}
write(out/'modular-grey-memory-review.json', review)
archive = out/'modular-grey-memory-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(w.rglob('*')):
        if not p.is_file() or any(part in ['cache','baseline','baseline-preflight','pre-safety','pr27','pr28','pr29'] for part in p.relative_to(w).parts): continue
        if p.suffix not in ['.py','.swift','.txt','.json','.log','.xml','.md']: continue
        z.write(p, str(p.relative_to(w)))
    for name in ['baseline','pre-safety']: z.writestr(name+'/build.json', (w/name/'build.json').read_text())
    z.writestr('qualification.json', json.dumps(report,indent=2)+'\n')
    z.writestr('review.json', json.dumps(review,indent=2)+'\n')
evidence = repo/'Documentation/Engineering/Migration/Evidence/ModularGreyMemory'
evidence.mkdir(exist_ok=True)
(evidence/'qualification.json').write_bytes((out/'modular-grey-memory-qualification.json').read_bytes())
(evidence/'raw-evidence.zip').write_bytes(archive.read_bytes())
(evidence/'README.md').write_text('# Modular greyscale memory evidence\n\nSee [the scoped report](../../MODULAR_GREY_MEMORY.md), [qualification index](qualification.json) and [raw evidence](raw-evidence.zip). Commands, final and superseded source snapshots, diagnostics, test/sanitizer logs, independent decoder checks, budget comparisons and both controlled measurements are retained. Absolute paths describe the executed environment. Compiled binaries and generated image payloads are omitted; their hashes remain.\n')
print(json.dumps({'validation':[(v['configuration'],v['xml']['declarations'],v['argumentCases']) for v in validation], 'regressions':regressions, 'archiveBytes':archive.stat().st_size}))
