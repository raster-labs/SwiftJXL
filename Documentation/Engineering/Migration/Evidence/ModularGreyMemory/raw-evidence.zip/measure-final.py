from pathlib import Path
from datetime import datetime, timezone
import json, subprocess
w=Path(__file__).resolve().parent
for kind in ['debug','release','asan','tsan']:
    assert json.loads((w/f'sampling-{kind}.json').read_text())['exit']==0
window={'startedUTC':datetime.now(timezone.utc).isoformat(),
        'otherLocalQualificationJobs':'All builds, tests, independent decode and admission probes completed before this window.'}
(w/'measurement-window.json').write_text(json.dumps(window,indent=2)+'\n')
for label in ['initial','repeat']:
    subprocess.run(['python3',str(w/'measure3.py'),label],check=True)
window['endedUTC']=datetime.now(timezone.utc).isoformat()
(w/'measurement-window.json').write_text(json.dumps(window,indent=2)+'\n')
subprocess.run(['python3',str(w/'measure-candidate-allocator.py')],check=True)
