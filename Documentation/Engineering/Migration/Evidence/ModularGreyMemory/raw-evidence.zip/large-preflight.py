from pathlib import Path
import ast, hashlib, json, subprocess, time
w=Path(__file__).resolve().parent
module=ast.parse((w/'preflight.py').read_text())
fn=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='pixels')
ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<synthetic expected samples>','exec'),ns)
module=ast.parse((w/'measure3.py').read_text())
cases=ast.literal_eval(next(x.value for x in module.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in x.targets)))
out=w/'large-preflight';out.mkdir(exist_ok=True)
report={'scope':'Exact independent decode on both sides of admission and bounded cancellation; internal effort only, serial and no public budget context.','cases':[]}
for name,width,height,channels,bits,effort,pattern in cases:
    expected=ns['pixels'](width,height,channels,bits,pattern)
    population=width*height*channels
    row=dict(name=name,population=population,learningSamples=min(population,256_000) if effort >= 8 else None,runs=[])
    for implementation in ['baseline','candidate']:
        stream=out/(name+'-'+implementation+'.jxl');pam=stream.with_suffix('.pam')
        command=[str(w/implementation/'probe'),str(width),str(height),str(channels),str(bits),str(effort),'0',pattern,str(stream)]
        start=time.monotonic();r=subprocess.run(command,text=True,capture_output=True,timeout=300)
        stream.with_suffix('.probe.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
        oracle=['/opt/homebrew/bin/djxl',str(stream),str(pam),f'--bits_per_sample={bits}','--num_threads=2','--quiet']
        o=subprocess.run(oracle,text=True,capture_output=True,timeout=120)
        stream.with_suffix('.oracle.log').write_text(o.stdout+o.stderr);assert o.returncode==0,o.stderr
        header,payload=pam.read_bytes().split(b'ENDHDR\n',1)
        fields=dict(line.split(maxsplit=1) for line in header.splitlines()[1:] if line and not line.startswith(b'#'))
        assert int(fields[b'WIDTH'])==width and int(fields[b'HEIGHT'])==height and int(fields[b'DEPTH'])==channels
        assert int(fields[b'MAXVAL'])==(1<<bits)-1 and payload==expected
        row['runs'].append(dict(implementation=implementation,command=command,exit=r.returncode,oracleCommand=oracle,oracleExit=o.returncode,exactSamples=True,encodedBytes=stream.stat().st_size,sha256=hashlib.sha256(stream.read_bytes()).hexdigest(),probe=json.loads(r.stdout),preflightSeconds=time.monotonic()-start))
    row['bytesUnchanged']=row['runs'][0]['sha256']==row['runs'][1]['sha256']
    row['sizeChangePercent']=(row['runs'][1]['encodedBytes']/row['runs'][0]['encodedBytes']-1)*100
    report['cases'].append(row)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,'exact independent decodes; size change',round(row['sizeChangePercent'],3),'percent',flush=True)
report['status']='passed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
