from pathlib import Path
import json,subprocess,hashlib
w=Path(__file__).resolve().parent;report={'scope':'Instrumented serial stage boundaries, timing excluded. Phase odd=end, even=begin. Malloc in-use is active zone payload; reserved is allocator-reserved memory; RSS remains process-wide.','runs':[]}
for name in ['pr27','pr29']:
 out=w/(name+'-trace');stream=out/'diagnostic.jxl'
 cmd=[str(out/'probe'),'512','511','1','16','8','10','mixed',str(stream)]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(out/'run.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 d=json.loads(r.stdout);phases=json.loads((out/'build.json').read_text())['phases'];rows=d['phaseTrace']
 report['runs'].append({'implementation':name,'command':cmd,'exit':r.returncode,'result':d,'codestreamSHA256':hashlib.sha256(stream.read_bytes()).hexdigest()})
 print(name,'phase maxima MiB',flush=True)
 for key,phase in phases.items():
  matches=[r for r in rows if r[0]//2==int(key)]
  print(phase,[round(max(r[i] for r in matches)/1024**2,2) for i in [1,2,3]],flush=True)
 peaks=[];high=0
 for r in rows:
  if r[3]>high:
   peaks.append([phases[str(r[0]//2)],'end' if r[0]%2 else 'begin',*[round(v/1024**2,2) for v in r[1:]]]);high=r[3]
 print('RSS increases',peaks,flush=True)
assert report['runs'][0]['codestreamSHA256']==report['runs'][1]['codestreamSHA256']
report['status']='passed';(w/'trace-report.json').write_text(json.dumps(report,indent=2)+'\n')
