from pathlib import Path
import json,subprocess,hashlib,xml.etree.ElementTree as ET,os
w=Path(__file__).resolve().parent;repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
d=json.loads((w.parent/'modular-effort-performance/sampling-debug.json').read_text());cmd=d['command'];cmd[cmd.index('--filter')+1]='greedyLeafRangesRetainEveryOriginalSample|policyFailuresEscapeThroughoutLearning';cmd[cmd.index('--xunit-output')+1]=str(w/'focused.xml')
hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for root in ['Sources','Tests'] for p in (repo/root).rglob('*.swift')}
with (w/'focused.log').open('w') as log:r=subprocess.run(cmd,cwd=repo,env={**os.environ,'SWIFTJXL_ORACLE_BIN':'/opt/homebrew/bin'},stdout=log,stderr=subprocess.STDOUT,timeout=600)
report={'command':cmd,'exit':r.returncode,'sourceHashes':hashes}
if (w/'focused.xml').exists():
 root=ET.parse(w/'focused.xml').getroot();report['xml']={k:len(list(root.iter(v))) for k,v in [('declarations','testcase'),('failures','failure'),('skips','skipped')]}
(w/'focused.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['sourceHashes','command']});print((w/'focused.log').read_text()[-1700:]);assert r.returncode==0
