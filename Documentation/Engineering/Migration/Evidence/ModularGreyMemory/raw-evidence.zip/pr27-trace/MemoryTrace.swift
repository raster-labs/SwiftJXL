// Diagnostic-only instrumentation. Probes use the serial fallback and never
// create workers. The mutable state below is accessed only by that one caller.
import Darwin
package enum MemoryTrace {
    private nonisolated(unsafe) static var storage = [UInt64](repeating: 0, count: 20000)
    private nonisolated(unsafe) static var cursor = 0
    package static func reset() { storage[0] = 0; cursor = 0 }
    package static func mark(_ phase: UInt64) {
        guard cursor + 4 <= storage.count else { return }
        var stats = malloc_statistics_t(); malloc_zone_statistics(nil, &stats)
        var usage = rusage(); _ = getrusage(RUSAGE_SELF, &usage)
        storage[cursor] = phase
        storage[cursor + 1] = UInt64(stats.size_in_use)
        storage[cursor + 2] = UInt64(stats.size_allocated)
        storage[cursor + 3] = UInt64(usage.ru_maxrss)
        cursor += 4
    }
    package static func records() -> [[UInt64]] {
        stride(from: 0, to: cursor, by: 4).map { Array(storage[$0..<($0 + 4)]) }
    }
}
