from pathlib import Path
import json,subprocess,hashlib
w=Path(__file__).resolve().parent;out=w/'candidate-allocator-history';out.mkdir(exist_ok=True)
report={'scope':'Diagnostic malloc-zone totals at encode boundaries; timings excluded, process RSS is not algorithm workspace.','runs':[]}
for implementation in ['pr27','pr29','candidate','candidate','pr29','pr27']:
 stem=str(len(report['runs']))+'-'+implementation
 cmd=[str(w/(implementation+'-memory')),'512','511','1','16','8','30','mixed',str(out/(stem+'.jxl'))]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(out/(stem+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 d=json.loads(r.stdout);h=d['memoryHistory'];row={'implementation':implementation,'command':cmd,'exit':r.returncode,'binarySHA256':hashlib.sha256((w/(implementation+'-memory')).read_bytes()).hexdigest(),'codestreamSHA256':hashlib.sha256((out/(stem+'.jxl')).read_bytes()).hexdigest(),'result':d}
 report['runs'].append(row);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(implementation,'MiB first/end/max', {k:[round(h[1][k]/1024**2,3),round(h[-1][k]/1024**2,3),round(max(x[k] for x in h)/1024**2,3)] for k in ['bytesInUse','highWaterTouchedBytes','reservedBytes','peakRSSBytes']},flush=True)
assert len(set(r['codestreamSHA256'] for r in report['runs']))==1
report['status']='passed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
