from pathlib import Path
p=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public/Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift');s=p.read_text()
a=s.index('    static func greedyTreeAndContexts(');b=s.index('\n    /// Greedy multi-property MA-tree candidate',a);t=s[a:b]
t=t.replace('            var idxs: [Int]','            let range: Range<Int>').replace('            init(_ i: [Int]) { idxs = i }','            init(_ range: Range<Int>) { self.range = range }')
anchor='        var loBuf = [Int](repeating: 0, count: maxTok + 1)\n'
t=t.replace(anchor,anchor+'''
        // All leaf ranges partition one index owner. A second fixed owner
        // provides stable partition scratch, avoiding fresh child allocations
        // for every split. Neither array nor its scoped borrows escapes.
        var indices = [Int](repeating: 0, count: n)
        var partitionScratch = [Int](repeating: 0, count: n)
        for i in 0..<n {
            if i & 1023 == 0 { try checkpoint() }
            indices[i] = i
        }
''')
t=t.replace('            let m = node.idxs.count','            let start = node.range.lowerBound\n            let m = node.range.count')
t=t.replace('node.idxs[j]','indices[start + j]').replace('node.idxs[i]','indices[start + i]')
start=t.index('        var rootIndices = [Int]()');end=t.index('        try computeBest(root,',start)
t=t[:start]+'        let root = GNode(0..<n)\n'+t[end:]
start=t.index('            // Size both children before allocating.');end=t.index('            try computeBest(L,',start)
t=t[:start]+'''            let start = node.range.lowerBound, end = node.range.upperBound
            var leftCount = 0
            for j in start..<end {
                if j & 1023 == 0 { try checkpoint() }
                if propsFlat[indices[j] * propCount + k] > s { leftCount += 1 }
            }
            if leftCount == 0 || leftCount == node.range.count {
                node.bestGain = -1; continue
            }
            let middle = start + leftCount
            try indices.withUnsafeMutableBufferPointer { source in
                try partitionScratch.withUnsafeMutableBufferPointer { scratch in
                    var left = start, right = middle
                    for block in stride(from: start, to: end, by: 1024) {
                        try checkpoint()
                        for j in block..<min(block + 1024, end) {
                            let i = source[j]
                            if propsFlat[i * propCount + k] > s {
                                scratch[left] = i; left += 1
                            } else {
                                scratch[right] = i; right += 1
                            }
                        }
                    }
                    // Read and write owners are disjoint. Preserve each
                    // side's encounter order and leave sibling ranges intact.
                    for block in stride(from: start, to: end, by: 1024) {
                        try checkpoint()
                        for j in block..<min(block + 1024, end) {
                            source[j] = scratch[j]
                        }
                    }
                }
            }
            node.prop = propIndices[k]
            node.split = s
            let L = GNode(start..<middle); let R = GNode(middle..<end)
            node.left = L; node.right = R
'''+t[end:]
t=t.replace('                for (j, i) in g.idxs.enumerated() {','                for j in g.range {').replace('                    contexts[i] = lid','                    contexts[indices[j]] = lid')
assert 'idxs' not in t and 'rootIndices' not in t
p.write_text(s[:a]+t+s[b:])
