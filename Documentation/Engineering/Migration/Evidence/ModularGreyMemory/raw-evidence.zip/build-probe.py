from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent
report={}
for name in ['pr27','pr28','pr29']:
 lib=w/name
 cmd=['xcrun','swiftc','-O','-g','-whole-module-optimization','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0','-module-cache-path',str(w/'cache'),'-package-name','SwiftJXL','-parse-as-library','-I',str(lib),str(w/'memory-probe.swift'),str(lib/'libSwiftJXLCore.a'),'-o',str(w/(name+'-memory'))]
 r=subprocess.run(cmd,capture_output=True,text=True);(w/(name+'-build.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 report[name]={'command':cmd,'exit':r.returncode,'librarySHA256':hashlib.sha256((lib/'libSwiftJXLCore.a').read_bytes()).hexdigest(),'probeSHA256':hashlib.sha256((w/(name+'-memory')).read_bytes()).hexdigest()}
(w/'build-probes.json').write_text(json.dumps(report,indent=2)+'\n')
print('Three diagnostic probes linked to the existing qualified libraries.')
