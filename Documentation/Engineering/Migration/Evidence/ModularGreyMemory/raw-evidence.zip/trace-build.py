from pathlib import Path
import json,hashlib,subprocess,sys,re
w=Path(__file__).resolve().parent;name=sys.argv[1];out=w/(name+'-trace');out.mkdir(exist_ok=True)
source=w/name
phases=['buildSingleSection','bestModularPostCodebook','wpGreedyPerPixel','buildSingleSectionMultiContext','activityThresholdSets' if name=='pr29' else 'learnedThresholdSets','costMultiContextSection','emitMultiContextSection','buildSingleSectionGreedyTree','greedyTreeAndContexts']
paths=[];original={};instrumented={}
for p in sorted((source/'Sources/SwiftJXLCore').rglob('*.swift')):
 rel=p.relative_to(source);data=p.read_text();original[str(rel)]=hashlib.sha256(data.encode()).hexdigest()
 if p.name=='SpecModularEncoder.swift':
  for i,phase in enumerate(phases,1):
   match=re.search(r'\bstatic func '+phase+r'\(',data);assert match,phase
   start=data.index('{',match.end())+1
   data=data[:start]+f'\n        MemoryTrace.mark({i*2})\n        defer {{ MemoryTrace.mark({i*2+1}) }}'+data[start:]
 dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(data);paths.append(str(dest));instrumented[str(rel)]=hashlib.sha256(data.encode()).hexdigest()
trace=out/'MemoryTrace.swift';trace.write_text('''// Diagnostic-only instrumentation. Probes use the serial fallback and never
// create workers. The mutable state below is accessed only by that one caller.
import Darwin
package enum MemoryTrace {
    private nonisolated(unsafe) static var storage = [UInt64](repeating: 0, count: 20000)
    private nonisolated(unsafe) static var cursor = 0
    package static func reset() { storage[0] = 0; cursor = 0 }
    package static func mark(_ phase: UInt64) {
        guard cursor + 4 <= storage.count else { return }
        var stats = malloc_statistics_t(); malloc_zone_statistics(nil, &stats)
        var usage = rusage(); _ = getrusage(RUSAGE_SELF, &usage)
        storage[cursor] = phase
        storage[cursor + 1] = UInt64(stats.size_in_use)
        storage[cursor + 2] = UInt64(stats.size_allocated)
        storage[cursor + 3] = UInt64(usage.ru_maxrss)
        cursor += 4
    }
    package static func records() -> [[UInt64]] {
        stride(from: 0, to: cursor, by: 4).map { Array(storage[$0..<($0 + 4)]) }
    }
}
''');paths.append(str(trace))
probe=out/'probe.swift';s=(w/'memory-probe.swift').read_text().replace('        let pattern = a[7]', '        MemoryTrace.reset()\n        let pattern = a[7]').replace('"memoryHistory": memoryHistory,','"memoryHistory": memoryHistory, "phaseTrace": MemoryTrace.records(),');probe.write_text(s)
flags=['-O','-g','-whole-module-optimization','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0','-module-cache-path',str(w/'cache'),'-package-name','SwiftJXL']
cmd=['xcrun','swiftc',*flags,'-parse-as-library','-module-name','SwiftJXLCore','-emit-module','-emit-module-path',str(out/'SwiftJXLCore.swiftmodule'),'-emit-library','-static',*paths,'-o',str(out/'libSwiftJXLCore.a')]
link=['xcrun','swiftc',*flags,'-parse-as-library','-I',str(out),str(probe),str(out/'libSwiftJXLCore.a'),'-o',str(out/'probe')]
for kind,command in [('build',cmd),('link',link)]:
 r=subprocess.run(command,capture_output=True,text=True);(out/(kind+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-2500:]
(out/'build.json').write_text(json.dumps({'name':name,'phases':dict(enumerate(phases,1)),'originalSourceHashes':original,'instrumentedSourceHashes':instrumented,'command':cmd,'linkCommand':link,'exit':0,'binarySHA256':hashlib.sha256((out/'probe').read_bytes()).hexdigest()},indent=2)+'\n')
print(name,'instrumented diagnostic built',flush=True)
