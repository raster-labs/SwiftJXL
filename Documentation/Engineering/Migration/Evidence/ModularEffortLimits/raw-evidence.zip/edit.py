from pathlib import Path
import re
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
p=repo/'Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift';s=p.read_text()
# Convert optional candidate errors to a policy-aware helper, preserving other failures as nil.
pos=0;count=0
while True:
 i=s.find('try? ',pos)
 if i<0:break
 start=i+5;j=s.find('(',start);depth=1;k=j+1
 while depth:
  if s[k]=='(':depth+=1
  elif s[k]==')':depth-=1
  k+=1
 expr=s[start:k];new='try ModularEffortWork.candidate { try '+expr+' }'
 s=s[:i]+new+s[k:];pos=i+len(new);count+=1
# All helper layers that can now propagate policy failures must throw.
throws_names=['costMultiGroupSections','costMultiContextSection','emitMultiContextSection','assembleMultiContextSection','analyticTotal','prefixBits','headerCodebookBits']
for name in throws_names:
 start=s.index('func '+name+'(');arrow=s.index(') ->',start);s=s[:arrow]+s[arrow:].replace(') ->',') throws ->',1)
# Explicit catches keep unencodable candidates optional, but propagate operation failures.
s=s.replace('catch { return Int.max }','catch { try ModularEffortWork.rethrowPolicyFailure(error); return Int.max }')
s=s.replace('catch { return nil }','catch { try ModularEffortWork.rethrowPolicyFailure(error); return nil }')
s=s.replace('catch { /* fall through to rANS */ }','catch { try ModularEffortWork.rethrowPolicyFailure(error) /* fall through to rANS */ }')
# Add try to helper call sites, not their definitions or existing try sites.
for name in throws_names:
 s=re.sub(r'\b'+name+r'\(',lambda m: m[0] if s[max(0,m.start()-5):m.start()].endswith(('func ','try ')) else 'try '+m[0],s)
s=s.replace('let groupHeaderBits: Int = {','let groupHeaderBits: Int = try {')
s=s.replace('let costed = candidates\n            .map','let costed = try candidates\n            .map')
# Cost loops check during tokenisation and grouped Huffman evaluation.
s=s.replace('for (i, t) in run.enumerated() {\n                let exp', 'for (i, t) in run.enumerated() {\n                if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }\n                let exp')
s=s.replace('for (i, t) in ordered.enumerated() {\n            let exp', 'for (i, t) in ordered.enumerated() {\n            if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }\n            let exp')
s=s.replace('for i in 0..<syms.count {\n                        let len','for i in 0..<syms.count {\n                        if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }\n                        let len')
# The shared property pass admits its own incremental workspace with checked arithmetic.
old='''        let propCount = includeTreeProperties ? 6 : 1
        let n = width * height * channels.count
        var propsFlat'''
new='''        let propCount = includeTreeProperties ? 6 : 1
        let perChannel = try ScalarOperationBudget.product(width, height)
        let workspace = try ModularEffortWork.propertyWorkspace(
            width: width, height: height, channels: channels.count, tree: includeTreeProperties)
        guard channels.allSatisfy({ $0.count == perChannel }) else {
            throw ScalarModularError.invalidInput("Incompatible Modular property planes")
        }
        let n = try ScalarOperationBudget.product(perChannel, channels.count)
        try ScalarEncodingWork.current?.budget.reserveWorkspace(workspace)
        var propsFlat'''
assert old in s;s=s.replace(old,new)
p.write_text(s);print('policy-aware optional sites:',count)
