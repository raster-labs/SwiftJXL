# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json
w=Path(__file__).resolve().parent;repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public');workspace=w.parent.parent
r=json.loads((w/'qualification.json').read_text())
rows=[]
for a,b in zip(r['comparisons'][0]['rows'],r['comparisons'][1]['rows']):
 rows.append(f"| {a['case']} | {a['medianChangePercent']:+.2f}% / {b['medianChangePercent']:+.2f}% | {a['baselinePeakRSSMiB']:.2f} → {a['candidatePeakRSSMiB']:.2f} / {b['baselinePeakRSSMiB']:.2f} → {b['candidatePeakRSSMiB']:.2f} |")
report='''# Modular candidate limits — 14 October 2026

## Observed failure and repair

The internal grouped encoder could ignore a workspace failure from an optional higher-effort activity candidate and return the effort-3 baseline. A pinned PR25 probe (`7ec288ce231091bd07c8f9aaacba487911deda02`) reproduces this with both two and eight workers: reserving exactly the baseline worker-result allowance, 1,280 bytes, permits the baseline but denies the next activity map. The old code silently returns byte-identical effort-3 output; the follow-up throws `ScalarModularError.resourceLimit` in both cases. This is a targeted worker-result reservation probe, not a complete encoder memory envelope or a failure of the public fixed-effort-3 profile.

Optional candidate costing, entropy construction and emission now propagate cancellation and resource failures. Ordinary format-unsuitable candidates remain optional. Pre/post checks also prevent an otherwise successful candidate, or an unrelated format error, from hiding a latched writer overflow, deadline or cancellation. Tokenisation, grouped Huffman costing and tree routing check every 1,024 samples. Pure `ModularTree.walk` format failures stay optional; they perform no allocation admission and routing supplies the policy checkpoints.

## Incremental shared-property reservation

Before `wpGreedyPerPixel` allocates, checked arithmetic validates dimensions, products and plane lengths, then reserves its additional workspace against the current operation budget. On 64-bit hosts, with `N = width*height*channels`:

| Mode | Additional cumulative reservation |
| --- | --- |
| Activity-only | `16*N + 96*(width+2)*channels + 256*(channels+3)` |
| Tree properties | `72*N + 96*(width+2)*channels + 256*(channels+3)` |

The sample term doubles the 8/36-byte visible array payload for capacity/transient overlap; predictor rows similarly reserve twice their 48-byte extended-column payload for each successive channel. Fixed allowances cover array/channel headers and rounding. It adds to existing reservations and does not make the effort-3 envelope sufficient for higher modes. Caller planes, grouped property collection, candidate buffers, sorting and learning still need full higher-effort admission. This reservation is not measured peak RSS or allocator telemetry.

## Executed qualification

Against PR25, contract 0.10.0 and predecessor pin `57e81cb9e2411d1efac435b429a306a031744c1e`:

- Debug, release, Address Sanitizer and Thread Sanitizer each pass 32 declarations / 202 argument cases on the same final 179 source/test hashes, without failures, skips or sanitizer diagnostics. New tests cover exact/cumulative property admission, invalid/overflowing geometry, cancelled/expired candidates, latched writer failures and the grouped fallback regression.
- All 54 new effort/case streams independently decode exactly with `djxl` 0.12.0 and match the previously independently verified PR25-compatible fixture bytes. The prior oracle baseline is explicitly reused, with source-equivalence proof; it is not counted as another newly executed oracle run.
- The paired policy probe reproduces the old bug and corrected behaviour against separately rebuilt PR25/follow-up libraries. Exact commands, hashes and results are in the archive.
- Initial closure-call syntax errors and sandbox macro-plugin build failures are retained separately from the corrected, passing runs.

See [qualification index](Evidence/ModularEffortLimits/qualification.json), [raw evidence](Evidence/ModularEffortLimits/raw-evidence.zip), [new regressions](../../../Tests/SwiftJXLCoreTests/ModularEffortLimitTests.swift) and [existing synthetic fixture provenance](../../../Tests/SwiftJXLCoreTests/Fixtures/Modular/Effort/provenance.json).

## Release timing and memory observations

Same Swift 6.4 optimisation, Swift 6 mode, complete concurrency checking, arm64 macOS 26.0 target and macOS 27.0.1 host as the prior qualification. Both baseline and candidate core libraries were rebuilt from their recorded sources. Two opposite interleavings use five warm-ups and ten timed iterations per block, twenty timed samples per implementation per case. No local build/test/profile runs overlap measurement. Thermal state is recorded; external system load is not measured. The probe is internal and serial, without a public operation budget context; the paired policy probe separately exercises two/eight workers.

Negative latency change is faster. Peak RSS is process-wide MiB, baseline → candidate. Raw records retain p95, spread, every timing and encoded size; all compared bytes are identical. The twelve larger benchmark-fixture oracle checks occur after timing and are retained separately. No speedup or complete algorithm-workspace claim follows from small differences.

| Case | Median change, initial / repeat | Peak RSS, initial / repeat |
| --- | --- | --- |
'''+ '\n'.join(rows)+'''

## Remaining qualification

Full higher-effort simultaneous/cumulative admission, sorting/learning cancellation and exact learner-sample bounds remain open. Public API and CLI effort remain fixed at 3; production limits, ownership, worker ceilings and all seven common contract files are unchanged. This local arm64 Swift 6.4 result does not establish hosted Swift 6.2, minimum-OS runtime, other platforms, complete public predecessor performance parity or release readiness. JPEG performance, VarDCT rate-distortion/ARM-oracle differences, animation steady-state and other Milestone 4 feature/platform gates remain separate. PR25 is a dependency; this follow-up does not merge it.
'''
(repo/'Documentation/Engineering/Migration/MODULAR_EFFORT_LIMITS.md').write_text(report)
(repo/'Documentation/Engineering/Migration/Evidence/ModularEffortLimits/README.md').write_text('''# Modular candidate-limit evidence

`qualification.json` indexes the scoped results. `raw-evidence.zip` retains the exact build/test/probe commands, source and binary hashes, test logs/XML, raw timings, oracle checks and unsuccessful build attempts. Paths in archived scripts describe the original workspace and need adaptation on another machine. It excludes binaries, copied source trees and decoded images.

`baseline` is PR25 commit 7ec288c; `candidate` is this follow-up. `baseline-reuse.json` and `reused-oracle-report.json` identify earlier oracle data reused with source equivalence, without claiming a new baseline oracle run. `policy-regression.json` records the reproducible old fallback and corrected rejection. `validation-command-inputs` preserves the older command templates, not new test claims. Only final `limits-debug/release/asan/tsan` records establish the combined final source qualification; earlier compile/debug attempts remain diagnostic history.
''')
for filename,heading,body in [
 ('HISTORY.md','## Modular candidate resource enforcement — 14 October 2026','A grouped higher-effort candidate could swallow a worker workspace rejection and return its effort-3 baseline. Propagate cancellation/resource errors through optional candidates, add bounded costing/routing checkpoints and reserve shared-property scratch with checked arithmetic before allocation. The old/new two- and eight-worker probe confirms the repair. Final affected debug/release/ASan/TSan each pass 32 declarations / 202 cases; 54 new independently decoded streams preserve fixture bytes. Public effort remains 3 and complete higher-effort admission remains open. See [qualification and remaining gates](Documentation/Engineering/Migration/MODULAR_EFFORT_LIMITS.md).'),
 ('CHANGELOG.md','## Unreleased — Modular candidate limits, 2026-10-14','- Propagate operation cancellation/resource failures from optional Modular candidates instead of silently selecting a fallback.\n- Admit shared-property scratch before allocation and checkpoint token costing/tree routing.\n- Retain the fixed public effort-3 profile while complete higher-effort admission and learner qualification continue.')]:
 p=repo/filename;s=p.read_text();a,b=s.split('\n',1);p.write_text(a+'\n\n'+heading+'\n\n'+body+'\n'+b)
p=repo/'Documentation/Engineering/Migration/RESOURCE_ADMISSION.md';s=p.read_text();s+='''\n## Internal higher-effort candidate enforcement — 14 October 2026

Optional Modular candidates now propagate operation resource/cancellation failures; an exhausted worker-result reservation cannot silently return a lower-effort result. The shared single-section property pass also reserves its own incremental array/predictor workspace before allocation, using checked products and input-plane validation. See [the precise reservation, old/new reproduction and tests](MODULAR_EFFORT_LIMITS.md).

This component reservation does not qualify the complete higher-effort envelope. Grouped property buffers, candidate routing/cost buffers, sorting and learners remain to be admitted together. Public effort stays at 3; its existing envelope is unchanged.
''';p.write_text(s)
p=repo/'MIGRATION.md';s=p.read_text();anchor='See [Modular effort qualification](Documentation/Engineering/Migration/MODULAR_EFFORT_QUALIFICATION.md).';assert anchor in s;s=s.replace(anchor,anchor+' The [candidate-limit follow-up](Documentation/Engineering/Migration/MODULAR_EFFORT_LIMITS.md) propagates policy failures and admits shared-property scratch; it does not expose higher public efforts.');p.write_text(s)
body='''Internal higher-effort grouped encoding could suppress a workspace failure from its activity candidate and return effort-3 output. The paired probe reproduces this on PR25 with both two and eight workers; this change propagates the resource-limit error. Optional candidates also preserve cancellation, deadline and latched output-limit failures. Add 1,024-sample checkpoints to costing/routing and checked incremental admission before shared-property arrays are allocated.

This follow-up depends on PR25 (7ec288c). Public API/CLI effort stays at 3; production limits, ownership and common contracts are unchanged.

Validation: debug/release/ASan/TSan each pass 32 declarations / 202 cases on matching final source/test hashes. All 54 new effort/case streams independently decode exactly and match the prior verified fixture bytes. Two opposite-order release comparisons retain 20 timed samples per implementation/case, raw spread/RSS and unchanged codestreams. No speedup or peak-workspace claim is made.

Review caveats: only the shared-property component receives new workspace admission. The complete higher-effort allocation envelope, sorting/learning checkpoints, exact sample cap, public effort controls and broader migration gates remain open. Local Swift 6.4 arm64 evidence is not hosted Swift 6.2 or minimum-OS qualification. The initial syntax/build-environment failures are retained. Current agent review found no blocking issue in this scoped repair; independent review and hosted checks remain pending.

Details, commands, hashes and measurements: Documentation/Engineering/Migration/MODULAR_EFFORT_LIMITS.md and Evidence/ModularEffortLimits/{qualification.json,raw-evidence.zip}.
'''
(workspace/'outputs/modular-effort-limits-draft-pr.txt').write_text(body)
print('Wrote review documentation and prepared follow-up draft description.')
