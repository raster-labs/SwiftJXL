from pathlib import Path
import json,subprocess,hashlib
w=Path(__file__).resolve().parent;rows=[]
for name in ['baseline','candidate']:
 d=json.loads((w/name/'build.json').read_text());cmd=d['linkCommand'].copy()
 cmd[cmd.index(str(w/'probe.swift'))]=str(w/'policy-probe.swift');cmd[-1]=str(w/name/'policy-probe')
 r=subprocess.run(cmd,capture_output=True,text=True);(w/name/'policy-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
 r=subprocess.run([cmd[-1]],capture_output=True,text=True);(w/name/'policy-run.log').write_text(r.stdout+r.stderr);assert r.returncode==0
 result=json.loads(r.stdout)
 assert all(x['outcome']=='resourceLimit' for x in result) if name=='candidate' else all(x.get('matchesEffort3') is True for x in result)
 rows.append({'implementation':name,'command':cmd,'exit':r.returncode,'binarySHA256':hashlib.sha256(Path(cmd[-1]).read_bytes()).hexdigest(),'results':result})
(w/'policy-regression.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
