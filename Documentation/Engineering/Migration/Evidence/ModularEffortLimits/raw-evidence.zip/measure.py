from pathlib import Path
import json,subprocess,hashlib,sys,statistics,math,time
w=Path(__file__).resolve().parent;label=sys.argv[1];out=w/label;out.mkdir(exist_ok=True)
cases=[('default-control',512,511,1,16,3,'mixed'),('gray-activity',512,511,1,16,7,'mixed'),('rgb-activity',512,511,3,8,7,'mixed'),('rgba-activity',256,255,4,16,4,'mixed'),('tree-control',128,127,3,8,8,'mixed'),('group-control',513,17,3,8,7,'mixed')]
order=['baseline','candidate','candidate','baseline'] if label=='initial' else ['candidate','baseline','baseline','candidate']
report={'status':'running','order':order,'scope':'Core whole encode, serial fallback, synthetic mixed ramp/noise. PR25 versus candidate-policy and property-admission follow-up; not public effort-3 predecessor performance closure.','cases':[],'binaries':{n:hashlib.sha256((w/n/'probe').read_bytes()).hexdigest() for n in ['baseline','candidate']}}
for name,width,height,channels,bits,effort,pattern in cases:
 row={'name':name,'width':width,'height':height,'channels':channels,'bits':bits,'effort':effort,'pattern':pattern,'runs':[]}
 first=None
 for block,implementation in enumerate(order):
  stream=out/f'{name}-{implementation}-{block}.jxl'
  command=[str(w/implementation/'probe'),str(width),str(height),str(channels),str(bits),str(effort),'10',pattern,str(stream)]
  r=subprocess.run(command,capture_output=True,text=True,timeout=600)
  (out/f'{name}-{implementation}-{block}.log').write_text(r.stdout+r.stderr)
  assert r.returncode==0,(command,r.stdout,r.stderr)
  encoded=stream.read_bytes()
  if first is None:first=encoded
  assert encoded==first,'Baseline/candidate codestream mismatch'
  result=json.loads(r.stdout);assert len(result['milliseconds'])==10 and result['warmups']==5
  row['runs'].append({'implementation':implementation,'block':block,'command':command,'exit':r.returncode,'result':result,'codestreamSHA256':hashlib.sha256(encoded).hexdigest()})
 summaries={}
 for implementation in ['baseline','candidate']:
  runs=[r['result'] for r in row['runs'] if r['implementation']==implementation];samples=sorted(v for r in runs for v in r['milliseconds'])
  summaries[implementation]={'medianMS':statistics.median(samples),'p95MS':samples[math.ceil(.95*len(samples))-1],'minimumMS':min(samples),'maximumMS':max(samples),'iterations':len(samples),'thermalStates':sorted(set(r[k] for r in runs for k in ['thermalStart','thermalEnd'])),'processPeakRSSBytes':max(r['processPeakRSSBytes'] for r in runs),'encodedBytes':runs[0]['encodedBytes']}
 summaries['medianChangePercent']=(summaries['candidate']['medianMS']/summaries['baseline']['medianMS']-1)*100
 row['summaries']=summaries;report['cases'].append(row);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(name,round(summaries['medianChangePercent'],2),'percent',flush=True)
report['status']='completed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
