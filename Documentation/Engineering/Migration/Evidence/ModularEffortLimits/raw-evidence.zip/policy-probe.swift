// SPDX-License-Identifier: Apache-2.0
import Foundation
import SwiftJXLCore

@main struct PolicyProbe {
    static func main() throws {
        let width = 513, height = 17
        let pixels = (0..<(width * height)).map { Int32(($0 * 71 + ($0 / width) * 37) & 65535) }
        var rows: [[String: Any]] = []
        for workers in [2, 8] {
            func context(_ workspace: Int) throws -> ScalarEncodingWork {
                let budget = try ScalarOperationBudget(retainedBytes: 0, maximumWorkspaceBytes: workspace,
                    maximumMemoryBytes: 16 * 1024 * 1024, maximumDecodedBytes: 1024 * 1024,
                    maximumCompressedBytes: 1024 * 1024, deadline: .now.advanced(by: .seconds(120)),
                    maximumWorkers: workers)
                return ScalarEncodingWork(budget: budget, writerByteLimit: 1024 * 1024)
            }
            func encode(_ work: ScalarEncodingWork, _ effort: Int) throws -> Data {
                try ScalarEncodingWork.$current.withValue(work) {
                    try SpecModularEncoder.encodeGrayscale16(width: width, height: height,
                        bitsPerSample: 16, pixelsInt32: pixels, effort: effort)
                }
            }
            let baseline = try context(1024 * 1024)
            let expected = try encode(baseline, 3)
            let limit = baseline.budget.reservedWorkspaceBytes
            let denied = try context(limit)
            var row: [String: Any] = ["workers": workers, "workspaceLimit": limit]
            do {
                let output = try encode(denied, 7)
                row["outcome"] = "returned baseline despite activity-candidate budget failure"
                row["matchesEffort3"] = output == expected
            } catch ScalarModularError.resourceLimit {
                row["outcome"] = "resourceLimit"
            }
            rows.append(row)
        }
        print(String(decoding: try JSONSerialization.data(withJSONObject: rows, options: [.sortedKeys]), as: UTF8.self))
    }
}
