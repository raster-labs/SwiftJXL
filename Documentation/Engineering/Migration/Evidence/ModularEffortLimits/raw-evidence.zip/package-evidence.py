# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,re,shutil,zipfile,datetime
w=Path(__file__).resolve().parent;prior=w.parent/'modular-effort';workspace=w.parent.parent
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
e=repo/'Documentation/Engineering/Migration/Evidence/ModularEffortLimits';e.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
validation=[];hashes=None
for n in ['debug','release','asan','tsan']:
 stem='limits-'+n;d=json.loads((prior/(stem+'.json')).read_text());assert d['exit']==0
 assert all(d['xml'][k]==0 for k in ['failures','errors','skips'])
 if hashes is None:hashes=d['sourceHashes']
 assert hashes==d['sourceHashes']
 assert all(digest(repo/p)==h for p,h in hashes.items())
 s=(prior/(stem+'.log')).read_text();args=re.findall(r'^◇ Test case passing .* to (.+?) started\.$',s,re.M);tests=re.findall(r'^◇ Test (?!case passing |run )(.+?) started\.$',s,re.M)
 cases=len(args)+len([x for x in tests if x not in set(args)])
 assert len(tests)==32 and cases==202,(n,len(tests),cases)
 assert not re.search(r'WARNING: ThreadSanitizer|ERROR: AddressSanitizer|SUMMARY: (?:ThreadSanitizer|AddressSanitizer)',s)
 validation.append({'configuration':n,'exit':0,'declarations':32,'argumentCases':202,'failures':0,'skips':0,'sanitizerDiagnostics':0,'report':'validation/'+stem+'.json'})
core=json.loads((w/'candidate/build.json').read_text())
assert all(digest(repo/p)==h for p,h in core['sourceHashes'].items())
oracle=json.loads((w/'candidate-preflight/report.json').read_text());assert oracle['status']=='passed' and oracle['caseCount']==54
assert all(c['exactSamples'] and c['matchesBaseline'] for c in oracle['cases'])
comparisons=[]
for name in ['initial','confirmation']:
 d=json.loads((w/name/'report.json').read_text());assert d['status']=='completed'
 rows=[]
 for c in d['cases']:
  a,b=c['summaries']['baseline'],c['summaries']['candidate'];assert a['iterations']==b['iterations']==20
  assert all(run['exit']==0 for run in c['runs']) and len({run['codestreamSHA256'] for run in c['runs']})==1
  rows.append({'case':c['name'],'medianChangePercent':c['summaries']['medianChangePercent'],'baselineMedianMS':a['medianMS'],'candidateMedianMS':b['medianMS'],'baselinePeakRSSMiB':a['processPeakRSSBytes']/1048576,'candidatePeakRSSMiB':b['processPeakRSSBytes']/1048576,'thermalStates':sorted(set(a['thermalStates']+b['thermalStates']))})
 comparisons.append({'label':name,'rows':rows,'report':name+'/report.json'})
contracts={}
for line in (repo/'Documentation/COMMON_CONTRACT_SHA256.txt').read_text().splitlines():
 h,name=line.split();assert digest(repo/'Documentation'/name)==h;contracts[name]=h
policy=json.loads((w/'policy-regression.json').read_text())
limits=['The property reservation covers only the shared single-section property pass. Full higher-effort cumulative/simultaneous admission remains unfinished.','Activity sorting/learning and greedy learner/sample-cap bounds remain open; added checkpoints do not establish end-to-end higher-effort cancellation latency.','Public API/CLI effort remains fixed at 3. No production limit, storage ownership, worker limit or common contract changed.','Performance measurements use the internal serial probe with no public budget context; the separate policy probe exercises budget contexts with two and eight workers.','The 54-case synthetic oracle corpus is scoped; wider profiles/precisions, large inputs, concurrent steady state, allocation counts and peak algorithm workspace remain unqualified.','Local Swift 6.4 on macOS arm64 does not qualify hosted Swift 6.2, minimum-OS runtime or other platforms.','Existing public Modular predecessor gaps and the broader Milestone 4 JPEG/VarDCT/animation/feature/platform gates remain open.']
r={'asOfUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Scoped local qualification complete; follow-up publication and hosted checks pending.','branch':'codex/swiftjxl-modular-effort-limits','base':'7ec288ce231091bd07c8f9aaacba487911deda02','dependsOn':'https://github.com/raster-labs/SwiftJXL/pull/25','contract':'0.10.0','predecessorPin':'57e81cb9e2411d1efac435b429a306a031744c1e','behaviour':'Optional Modular candidates propagate operation cancellation/resource failures; format-unsuitable candidates remain optional. Check tokenisation, grouped Huffman costing and tree routing every 1024 samples. Reserve shared property arrays and predictor rows before allocation using checked arithmetic.','propertyReservation':{'N':'width*height*channels','activityBytes':'16*N + 96*(width+2)*channels + 256*(channels+3)','treeBytes':'72*N + 96*(width+2)*channels + 256*(channels+3)','meaning':'Incremental cumulative bound on 64-bit hosts, twice visible property/predictor-row payload plus fixed allowances; not peak RSS or complete higher-effort admission.'},'policyRegression':policy,'validation':validation,'independentOracle':{'newCandidateDecodes':54,'allExact':True,'allByteIdenticalToPR25Fixtures':True,'baseline':'Prior independently verified fixtures reused with source-equivalence proof in baseline-reuse.json.'},'comparisons':comparisons,'sourceAndTestHashes':hashes,'commonContractHashes':contracts,'compiler':core['compiler'],'os':core['os'],'hardware':(prior/'hardware.txt').read_text(),'limitations':limits,'retainedFailures':['Initial compile attempt needed parentheses around throwing closure calls in guard conditions.','Sandboxed static builds could not run compiler macro plugins; authorised retries succeeded.']}
(w/'qualification.json').write_text(json.dumps(r,indent=2)+'\n')
# One small archive retains raw evidence; no rebuilt binaries or decoded images.
archive=w/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['baseline','candidate','candidate-preflight','initial','confirmation','initial-sandbox-build-failures']:
  for p in (w/name).rglob('*'):
   if p.is_file() and p.suffix in ['.json','.log'] and 'Sources' not in p.parts:z.write(p,str(p.relative_to(w)))
 for p in w.iterdir():
  if p.is_file() and p.suffix in ['.py','.swift','.json','.log']:z.write(p,p.name)
 for p in prior.glob('limits-*'):
  if p.is_file() and p.suffix in ['.json','.log','.xml']:z.write(p,'validation/'+p.name)
 for name in ['focused','release','asan','tsan']:
  p=w.parent/'storage-read/validation'/f'{name}.json';z.write(p,'validation-command-inputs/'+p.name)
 z.write(prior/'validate.py','validate.py');z.write(prior/'hardware.txt','hardware.txt')
for target in [e/'qualification.json',workspace/'outputs/modular-effort-limits-qualification.json']:shutil.copy2(w/'qualification.json',target)
for target in [e/'raw-evidence.zip',workspace/'outputs/modular-effort-limits-evidence.zip']:shutil.copy2(archive,target)
print(json.dumps({'tests':validation,'sourceHashes':len(hashes),'archiveBytes':archive.stat().st_size,'comparisons':comparisons},indent=2))
