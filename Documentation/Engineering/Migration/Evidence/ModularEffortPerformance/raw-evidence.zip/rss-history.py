from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;out=w/'rss-history';out.mkdir(exist_ok=True)
report={'scope':'Allocation-history diagnostic; timings excluded from qualification.', 'runs':[]}
for iterations in [0,1,10,100]:
 for implementation in ['candidate','baseline','pre-safety','pre-safety','baseline','candidate']:
  stem=f'{iterations}-{implementation}-{len(report["runs"])}'
  cmd=[str(w/implementation/'probe'),'512','511','1','16','8',str(iterations),'mixed',str(out/(stem+'.jxl'))]
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr
  result=json.loads(r.stdout);report['runs'].append({'command':cmd,'exit':r.returncode,'iterations':iterations,'implementation':implementation,'result':result})
  (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  print(iterations,implementation,round(result['processPeakRSSBytes']/1024**2,3),flush=True)
