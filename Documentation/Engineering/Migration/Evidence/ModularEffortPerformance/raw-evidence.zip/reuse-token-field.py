from pathlib import Path
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
p=repo/'Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift';s=p.read_text();a=s.index('    static func activityThresholdSets(');b=s.index('    /// Analytically cost',a);part=s[a:b]
old='''        var toks = [Int]()
        toks.reserveCapacity(n)
        for (i, pair) in sorted.enumerated() {
            if i & 1023 == 0 { try checkpoint() }
            toks.append(Int(postCfg.encode(pair.token).token))
        }
'''
new='''        // The private sorted copy needs only token buckets from this point.
        // Reuse its UInt32 field instead of allocating another Int per sample;
        // the caller's original-order residual tokens are retained unchanged.
        try sorted.withUnsafeMutableBufferPointer { samples in
            for start in stride(from: 0, to: n, by: 1024) {
                try checkpoint()
                let end = start + min(1024, n - start)
                for i in start..<end { samples[i].token = postCfg.encode(samples[i].token).token }
            }
        }
'''
assert old in part;part=part.replace(old,new,1).replace('hiCount[toks[i]]','hiCount[Int(sorted[i].token)]').replace('let tk = toks[i]','let tk = Int(sorted[i].token)');s=s[:a]+part+s[b:];p.write_text(s)
