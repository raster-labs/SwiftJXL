from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

w = Path(__file__).resolve().parent
out = w.parent.parent / 'outputs'
repo = Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
def read(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, d): p.write_text(json.dumps(d, indent=2) + '\n')
hashes = {str(p.relative_to(repo)): digest(p) for folder in ['Sources', 'Tests'] for p in (repo/folder).rglob('*.swift')}
validation = []
for config in ['debug', 'release', 'asan', 'tsan']:
    d = read(w/f'sampling-{config}.json')
    assert d['exit'] == 0 and d.pop('sourceHashes') == hashes
    assert d['xml']['failures'] == d['xml']['errors'] == d['xml']['skips'] == 0
    log = (w/f'sampling-{config}.log').read_text()
    cases = [int(n) for n in re.findall(r'✔ Test [^\n]+ with (\d+) test cases passed', log)]
    d['argumentCases'] = d['xml']['declarations'] - len(cases) + sum(cases)
    assert not re.search(r'(ERROR: AddressSanitizer|WARNING: ThreadSanitizer|SUMMARY: (?:AddressSanitizer|ThreadSanitizer))', log)
    validation.append(d)
build = read(w/'candidate/build.json')
assert all(hashes[p] == h for p, h in build['sourceHashes'].items())
assert digest(w/'candidate/probe') == build['binarySHA256']
reuse = read(w/'baseline-reuse.json')
for name, d in reuse.items():
    assert d['matchedCoreFiles'] == 98
    assert digest(w/name/'probe') == d['binarySHA256']
    assert d['priorBuild']['probeSHA256'] == build['probeSHA256'] == digest(w/'probe.swift')
    for path, h in d['priorBuild']['sourceHashes'].items():
        source = subprocess.check_output(['git', 'show', d['head']+':'+path], cwd=repo)
        assert hashlib.sha256(source).hexdigest() == h
small = read(w/'candidate-preflight/report.json')
large = read(w/'large-preflight/report.json')
policy = read(w/'policy/report.json')
assert small['status'] == large['status'] == policy['status'] == 'passed'
assert len(small['cases']) == 54 and len(large['cases']) == 7 and len(policy['cases']) == 42
comparisons = []
for label in ['initial', 'repeat']:
    d = read(w/label/'report.json')
    assert d['status'] == 'completed' and len(d['cases']) == 7
    assert d['binaries']['candidate'] == build['binarySHA256']
    for row in d['cases']:
        independent = next(r for r in large['cases'] if r['name'] == row['name'])
        for run in row['runs']:
            name = run['implementation']
            if name != 'candidate': assert d['binaries'][name] == reuse[name]['binarySHA256']
            oracle = next(r for r in independent['runs'] if r['implementation'] == ('baseline' if name == 'pre-safety' else name))
            assert run['codestreamSHA256'] == oracle['sha256']
        s = row['summaries']
        for reference in ['baseline', 'pre-safety']:
            s[reference+'RSSChangePercent'] = (s['candidate']['processPeakRSSBytes']/s[reference]['processPeakRSSBytes']-1)*100
    comparisons.append({'label': label, 'order': d['order'], 'cases': [{k:v for k,v in r.items() if k != 'runs'} for r in d['cases']]})
regressions = []
for i, row in enumerate(comparisons[0]['cases']):
    for reference, latencyKey in [('baseline','medianChangePercent'), ('pre-safety','preSafetyMedianChangePercent')]:
        latency = [c['cases'][i]['summaries'][latencyKey] for c in comparisons]
        rss = [c['cases'][i]['summaries'][reference+'RSSChangePercent'] for c in comparisons]
        if all(x > 5 for x in latency) or all(x > 5 for x in rss):
            regressions.append({'case':row['name'], 'reference':reference, 'latencyChangePercent':latency, 'peakRSSChangePercent':rss})
prior = read(out/'modular-effort-budget-qualification.json')
contracts = prior['commonContractHashes']
assert all(digest(repo/p) == h for p,h in contracts.items())
history = read(w/'rss-history/report.json')
assert history['status'] == 'completed' and len(history['runs']) == 24
assert history['binaries']['candidate'] == build['binarySHA256']
report = {
    'asOfUTC':datetime.now(timezone.utc).isoformat(),
    'status':'Scoped local qualification; hosted and broader Milestone 4 gates remain open.',
    'branch':'codex/swiftjxl-modular-learner-performance',
    'base':'0ff82d1aa66cca66a5fed583aed742e360b5b438',
    'targetBaseBranch':'codex/swiftjxl-modular-effort-budget',
    'preSafetyReference':'ffeeef7e9f8807a6ad575ba416842df984bf8283',
    'contract':'0.10.0', 'predecessorPin':'57e81cb9e2411d1efac435b429a306a031744c1e',
    'change':[
        'Share one stable activity ordering between percentile and learned thresholds; release analysis scratch before candidate routing and costing.',
        'Reuse the private sorted residual-token field for token buckets, avoiding another Int array while preserving caller tokens.',
        'Use at most half-length independent scratch in bounded stable merging; synchronous borrows do not escape.',
        'Count each greedy child before reserving its indices, retaining original ordering and bounded cancellation checks.',
        'Preserve cumulative workspace admission, error propagation, candidate ordering, byte output and public effort 3.'
    ],
    'validation':validation,
    'independentOracle':{'tool':'djxl 0.12.0', 'smallCases':54, 'largerControlCases':7, 'largerIndependentDecodes':14, 'result':'All decoded samples exact; codestream bytes match PR28 and PR27. Timed hashes match independently decoded streams.'},
    'policy':{'cases':42, 'workers':[1,2,8], 'efforts':[7,9], 'result':'Unchanged ample-budget bytes and cumulative reservations; both versions reject at one byte below the exact reservation. Tests separately cover exact and aggregate memory limits.', 'evidence':'policy/report.json', 'allocatorTelemetry':False},
    'comparisons':comparisons,
    'performanceGate':{'status':'Open: repeated single-grey process RSS increase against PR27; no release-baseline waiver.' if regressions else 'No repeated final scoped threshold breach; wider qualification remains open.', 'confirmedOverFivePercent':regressions, 'scope':'Repeated core median latency and process peak RSS; no claim of broad predecessor or steady-state allocation qualification.', 'next':'Attribute the single-grey memory peak with allocation/lifetime telemetry across repeated and concurrent encodes; retain both final comparison breaches and the different longer-run observations.'},
    'measurementProtocol':{'warmupsPerBlock':5, 'timedIterationsPerBlock':10, 'timedIterationsPerImplementationPerCasePerComparison':20, 'noConcurrentLocalQualificationJobs':True, 'evidence':'measurement-window.json'},
    'allocationHistoryDiagnostic':history,
    'sourceAndTestHashes':hashes, 'commonContractHashes':contracts,
    'baselineReuse':{k:{a:b for a,b in v.items() if a!='priorBuild'} for k,v in reuse.items()},
    'environment':{'compiler':build['compiler'], 'os':build['os'], 'target':'arm64-apple-macos26.0'},
    'retainedExperiments':[
        'Shared activity ordering, half-length scratch and private token reuse were measured separately; all earlier observations remain in the archive.',
        'Explicitly clearing the root-index temporary did not establish a reliable memory benefit and was reverted.',
        'Exact child sizing reduces excess child capacity and selected large-case RSS; the extra counting pass remains checkpointed.',
        'Swift macro compilation initially failed under the process sandbox; the preserved failure was followed by a successful authorised build outside that sandbox.'
    ],
    'limitations':[
        'Public API and CLI effort remain 3. This does not expose higher efforts or establish production readiness.',
        'Process peak RSS varies with allocation history. The earlier single-grey memory increase and all outliers remain recorded; this is not an allocator-level attribution or peak algorithm workspace measurement.',
        'Cumulative admission remains deliberately conservative and unchanged, even where live arrays are smaller.',
        'Bounded loop checks do not provide a real-time cancellation guarantee for allocation, COW or runtime work.',
        'Timing uses serial internal encoding without a budget context. Worker-budget probes are not concurrent steady-state memory qualification.',
        'Local Swift 6.4 arm64 evidence does not qualify hosted Swift 6.2, Linux, physical Apple devices or minimum OS runtime.',
        'Broader Modular predecessor performance, VarDCT ARM reference differences, JPEG and animation, feature reconciliation and Apple runtime gates remain open. Milestone 4 is incomplete; JXLSwift remains the supported production route.'
    ]
}
write(out/'modular-effort-performance-qualification.json', report)
review = {'asOfUTC':report['asOfUTC'], 'reviewer':'Current coding agent; fresh source review, not an independent GitHub approval', 'base':report['base'], 'sourceAndTestHashes':hashes, 'correctnessFindings':[], 'qualificationFindings':regressions, 'scope':[
    'Reviewed percentile equivalence, original stable pair order, private token COW and unchanged fixed-before-learned candidate selection.',
    'Checked shorter-run bounds, forward/backward stable ties, initialized scratch and synchronous nonescaping buffer borrows, including cancellation unwind.',
    'Checked exact child capacity counting and stable partition ordering against unchanged conservative admission.',
    'Verified final tests, sanitizers, budget boundaries, independent decodes and exact benchmark source/binary hashes.'
], 'limitations':report['limitations']}
write(out/'modular-effort-performance-review.json', review)
archive = out/'modular-effort-performance-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(w.rglob('*')):
        if not p.is_file() or any(part in ['cache','baseline','baseline-preflight','pre-safety'] for part in p.relative_to(w).parts): continue
        if p.suffix not in ['.py','.swift','.txt','.json','.log','.xml','.md']: continue
        z.write(p, str(p.relative_to(w)))
    for name in ['baseline','pre-safety']: z.writestr(name+'/build.json', (w/name/'build.json').read_text())
    z.writestr('qualification.json', json.dumps(report,indent=2)+'\n')
    z.writestr('review.json', json.dumps(review,indent=2)+'\n')
evidence = repo/'Documentation/Engineering/Migration/Evidence/ModularEffortPerformance'
evidence.mkdir(exist_ok=True)
(evidence/'qualification.json').write_bytes((out/'modular-effort-performance-qualification.json').read_bytes())
(evidence/'raw-evidence.zip').write_bytes(archive.read_bytes())
(evidence/'README.md').write_text('# Modular learner performance evidence\n\nSee [the scoped report](../../MODULAR_EFFORT_PERFORMANCE.md), [qualification index](qualification.json) and [raw evidence](raw-evidence.zip). The archive retains executed commands, final and superseded source snapshots, validation, independent-decoder logs, admission checks, profiling, allocation-history diagnostics and both interleaved comparisons. Absolute paths identify the executed environment; adjust them to reproduce. Compiled binaries and generated image payloads are omitted, with their hashes retained. Public effort remains 3.\n')
print(json.dumps({'validation':[(v['configuration'],v['xml']['declarations'],v['argumentCases']) for v in validation], 'regressions':regressions, 'archiveBytes':archive.stat().st_size}))
