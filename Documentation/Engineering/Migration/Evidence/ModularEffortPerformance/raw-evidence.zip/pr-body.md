PR28 introduced repeated higher-effort latency costs while adding bounded cancellation and cumulative memory admission. Share one stable activity analysis, reuse its private token storage, reduce merge scratch to half length, and reserve greedy child indices by their actual counts. Candidate order, scoped encoded bytes, cancellation propagation, conservative reservations and public effort 3 remain unchanged.

This draft is stacked on #28. Two interleaved release comparisons show activity cases 14.2–15.0% faster and selected large tree cases 2.8–6.3% faster than PR28. All selected latency comparisons stay below a repeated 5% increase against PR27.

**Open performance gate:** 512×511 greyscale peak process RSS is 7.2% / 17.6% above PR27 in the final comparisons. Longer allocation-history diagnostics give different relative peaks; all observations are retained. This is not complete memory-regression closure or release-baseline acceptance.

Validation: debug and release each pass 42 declarations / 254 cases; ASan and TSan each pass 20 / 128, with no failures, skips or sanitizer diagnostics. All 54 small and 14 larger/control independent decodes are sample-exact with unchanged bytes. All 42 worker-budget comparisons preserve reservations and reject one byte below the exact allowance. Final source/binary hashes, commands, profiles, raw comparisons and discarded experiments are recorded in `Documentation/Engineering/Migration/MODULAR_EFFORT_PERFORMANCE.md` and its evidence archive.

Broader Milestone 4, hosted/platform and public higher-effort qualification remain open.
