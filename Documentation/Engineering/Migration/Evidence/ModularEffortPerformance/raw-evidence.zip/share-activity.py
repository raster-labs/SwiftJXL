from pathlib import Path
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
p=repo/'Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift';s=p.read_text()
s=s.replace('''    /// Returns one sorted set per depth that fully split with strictly
    /// increasing thresholds; stops early if a range can't be split.
    static func learnedThresholdSets(''','''    /// One stable ordering supplies both the fixed octiles and learned
    /// thresholds. Return only these small sets so sorting/learning scratch
    /// is released before candidate routing/costing begins. Learned sets
    /// stop early when a range cannot split with increasing thresholds.
    static func activityThresholdSets(''',1)
s=s.replace('''    ) throws -> [[Int32]] {
        let n = pairs.count
        guard n >= 2, maxDepth >= 1 else { return [] }
        guard maxDepth <= 3 else { throw ScalarModularError.resourceLimit }
        try checkpoint()
''','''    ) throws -> (octiles: [Int32], learned: [[Int32]]) {
        try checkpoint()
        let n = pairs.count
        guard n > 0 else { return ([], []) }
        guard (1...3).contains(maxDepth) else { throw ScalarModularError.resourceLimit }
        if n == 1 { return (Array(repeating: pairs[0].wpProp, count: 7), []) }
''',1)
needle='''        try ModularEffortWork.sort(&sorted, by: { $0.wpProp < $1.wpProp }, checkpoint: checkpoint)
        let maxTok'''
replace='''        try ModularEffortWork.sort(&sorted, by: { $0.wpProp < $1.wpProp }, checkpoint: checkpoint)
        // Preserve the original floor-based percentile rule, including ties.
        let octiles = (1...7).map { k in
            sorted[min(n - 1, max(0, Int(Double(n) * (Double(k) / 8.0))))].wpProp
        }
        let maxTok'''
assert needle in s;s=s.replace(needle,replace,1)
start=s.index('    static func activityThresholdSets(');end=s.index('    /// Analytically cost',start);part=s[start:end];assert 'return sets' in part;part=part.replace('return sets','return (octiles, sets)');s=s[:start]+part+s[end:]
# Grouped collection: retain write order and sort only the existing flattened pairs.
start=s.index('        var allProps: [Int32] = []');end=s.index('        // Cost one N-bin activity',start)
replacement='''        for ci in 0..<chCount {
            for gi in 0..<numGroups {
                try ScalarEncodingWork.checkpoint()
                perGroupPixels[gi].append(contentsOf: rectPixels[ci * numGroups + gi])
            }
        }
        var learningPairs = [(wpProp: Int32, token: UInt32)]()
        learningPairs.reserveCapacity(samples)
        for group in perGroupPixels {
            for (i, pair) in group.enumerated() {
                if i & 1023 == 0 { try ScalarEncodingWork.checkpoint() }
                learningPairs.append(pair)
            }
        }
        let thresholds = try activityThresholdSets(
            pairs: learningPairs, postCfg: postCfg, maxDepth: 3)

'''
s=s[:start]+replacement+s[end:]
start=s.index('        // Learned (entropy-optimal)',s.index('    private static func buildSectionsMultiContext('));a=s.index('        var learningPairs',start);end=s.index('            let isFixed',a)
s=s[:a]+'''        for l in thresholds.learned {
'''+s[end:]
# Single-section path likewise needs no separate property array/sort.
start=s.index('        var sortedProps = [Int32]()',s.index('    private static func buildSingleSectionMultiContext('));end=s.index('        // Cost one N-bin WP-activity',start)
s=s[:start]+'''        let thresholds = try activityThresholdSets(
            pairs: perPixel, postCfg: postCfg, maxDepth: 3)

'''+s[end:]
old='''        for l in try learnedThresholdSets(
            pairs: perPixel, postCfg: postCfg, maxDepth: 3) {''';assert old in s;s=s.replace(old,'        for l in thresholds.learned {',1)
assert s.count('let median = pct(0.5)')==2
s=s.replace('let median = pct(0.5)','let median = thresholds.octiles[3]')
s=s.replace('let q1 = pct(0.25), q2 = pct(0.5), q3 = pct(0.75)','let q1 = thresholds.octiles[1], q2 = median, q3 = thresholds.octiles[5]')
s=s.replace('let oct = (1...7).map { pct(Double($0) / 8.0) }','let oct = thresholds.octiles')
p.write_text(s)
p=repo/'Tests/SwiftJXLCoreTests/ModularEffortBudgetTests.swift';s=p.read_text().replace('SpecModularEncoder.learnedThresholdSets(','SpecModularEncoder.activityThresholdSets(').replace('#expect(!result.isEmpty)','#expect(!result.learned.isEmpty)');p.write_text(s)
