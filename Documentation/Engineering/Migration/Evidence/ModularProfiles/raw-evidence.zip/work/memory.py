from pathlib import Path
import hashlib, json, os, subprocess, time
w=Path(__file__).resolve().parent
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
prior=Path('/Users/raster/Documents/Codex/2026-10-14/swiftjxl-milestone4-pr26-pr27-continuation/work/modular-grey-memory/candidate')
build=json.loads((prior/'build.json').read_text())
assert all(hashlib.sha256((repo/k).read_bytes()).hexdigest()==v for k,v in build['sourceHashes'].items())
assert hashlib.sha256((prior/'probe').read_bytes()).hexdigest()==build['binarySHA256']
source=(repo/'Tests/SwiftJXLCoreTests/ModularProfileTests.swift').read_text().split('struct ModularProfileTests {')[0]
source=source.replace('import Testing\n','').replace('@testable import SwiftJXLCore','import SwiftJXLCore')
(w/'profile-fixture.swift').write_text(source)
cmd=['xcrun','swiftc','-O','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0',
     '-module-cache-path',str(w/'module-cache'),'-package-name','SwiftJXL','-parse-as-library','-I',str(prior),
     str(w/'profile-fixture.swift'),str(w/'concurrent-memory.swift'),str(prior/'libSwiftJXLCore.a'),'-o',str(w/'concurrent-memory')]
env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
start=time.monotonic()
r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=120)
(w/'memory-build-final.log').write_text(r.stdout+r.stderr)
report=dict(command=cmd,exit=r.returncode,seconds=time.monotonic()-start,reusedCoreHashes=build['sourceHashes'],
            matchedCoreFiles=len(build['sourceHashes']),librarySHA256=hashlib.sha256((prior/'libSwiftJXLCore.a').read_bytes()).hexdigest(),
            previousProbeSHA256=build['binarySHA256'],sourceRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip())
assert r.returncode==0,r.stderr
report['binarySHA256']=hashlib.sha256((w/'concurrent-memory').read_bytes()).hexdigest()
report['harnessHashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'profile-fixture.swift',w/'concurrent-memory.swift']}
(w/'memory-build-final.json').write_text(json.dumps(report,indent=2)+'\n')
for name,args in [('greyalpha-horizontal',[513,7,2,11,9]),('rgba-vertical',[7,513,4,11,9]),('greyalpha-larger',[513,127,2,13,8])]:
    name += '-final'
    stream=w/(name+'.jxl')
    command=[str(w/'concurrent-memory'),*map(str,args)]
    start=time.monotonic()
    r=subprocess.run(command,env=dict(env,SWIFTJXL_PROBE_STREAM=str(stream)),capture_output=True,text=True,timeout=600)
    (w/(name+'.log')).write_text(r.stdout+r.stderr)
    result=dict(command=command,exit=r.returncode,seconds=time.monotonic()-start)
    if r.returncode==0:
        result['observations']=json.loads(r.stdout)
        width,height,channels,bits,effort=args
        pam=w/(name+'.pam')
        oracle=['/opt/homebrew/bin/djxl',str(stream),str(pam),f'--bits_per_sample={bits}','--num_threads=2','--quiet']
        decoded=subprocess.run(oracle,capture_output=True,text=True,timeout=60)
        (w/(name+'-oracle.log')).write_text(decoded.stdout+decoded.stderr)
        result['oracleCommand']=oracle;result['oracleExit']=decoded.returncode
        assert decoded.returncode==0
        expected=bytearray();random=20261014;maximum=(1<<bits)-1
        for i in range(width*height):
            for c in range(channels):
                random=(random*1664525+1013904223)&0xffffffff
                ramp=(i%width)*71+(i//width)*108+c*113
                value=(ramp if i%23<11 else random>>8)&maximum
                if i%127==0:value=maximum if c%2==0 else 0
                if i%127==1:value=0 if c%2==0 else maximum
                if bits>8:expected.append(value>>8)
                expected.append(value&255)
        header,payload=pam.read_bytes().split(b'ENDHDR\n',1)
        lines=header.splitlines()
        result['exactIndependentSamples']=(lines[0]==b'P7' and f'WIDTH {width}'.encode() in lines and
            f'HEIGHT {height}'.encode() in lines and f'DEPTH {channels}'.encode() in lines and
            f'MAXVAL {maximum}'.encode() in lines and payload==expected)
        result['codestreamSHA256']=hashlib.sha256(stream.read_bytes()).hexdigest()
        assert result['exactIndependentSamples']
    (w/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(name,r.returncode,round(result['seconds'],3),flush=True)
