from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, zipfile

root = Path(__file__).resolve().parent.parent
w, out = root / 'work', root / 'outputs'
repo = Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
evidence = repo / 'Documentation/Engineering/Migration/Evidence/ModularProfiles'
prior = repo / 'Documentation/Engineering/Migration/Evidence/ModularGreyMemory/qualification.json'
old = json.loads(prior.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
base = '6f1ede976a5e99a6d7c6529865f57cf6c9be7169'
assert git('rev-parse', 'HEAD') == base
assert git('diff', base, '--', 'Sources', 'Package.swift', '.github', 'Documentation/COMMON_CONTRACT_SHA256.txt') == ''
for path, expected in old['sourceAndTestHashes'].items():
    assert digest(repo / path) == expected, path
for path, expected in old['commonContractHashes'].items():
    assert digest(repo / path) == expected, path

configurations = ['debug-final', 'release-unsandboxed', 'asan-final', 'tsan-final']
validation, streams = [], []
source_hashes = None
sanitizer = r'ERROR: (?:AddressSanitizer|LeakSanitizer)|WARNING: ThreadSanitizer|SUMMARY: .*Sanitizer|runtime error:|data race'
for name in configurations:
    r = read(w / name / 'report.json')
    assert r['exit'] == 0 and r['sourceUnchanged']
    assert r['caseExecutions'] == 90 and r['oracleOutputs'] == 74
    assert r['xml'] == dict(declarations=4, failures=0, errors=0, skips=0)
    log = (w / name / 'tests.log').read_text()
    assert not re.search(sanitizer, log)
    if source_hashes is None:
        source_hashes = r['sourceHashes']
    assert r['sourceHashes'] == source_hashes
    r = {k:v for k,v in r.items() if k != 'sourceHashes'}
    r['archiveDirectory'] = 'work/' + name
    r['environment'].update(CLANG_MODULE_CACHE_PATH=str(repo / '.build/module-cache'),
                            SWIFTPM_MODULECACHE_OVERRIDE=str(repo / '.build/module-cache'))
    r['sanitizerDiagnosticMatches'] = 0
    validation.append(r)
    streams.append(Counter(digest(p) for p in (w / name / 'oracle').glob('*/native.jxl')))
assert all(s == streams[0] for s in streams)
assert all(digest(repo / p) == h for p,h in source_hashes.items())

investigation = []
notes = {
    'debug-initial': 'Module-cache sandbox denial prevented compilation; no tests executed.',
    'debug-cache-fixed': 'The 256 MiB test allowance correctly refused four eight-worker effort-9 cases. The final correctness allowance is 512 MiB and dedicated 256 MiB refusal regressions were added. The original report counter was faulty; started cases are recounted from its retained log below.',
    'release-final': 'Sandbox denial in GenerateDSYMFile prevented tests. The unchanged source passed the authorised unsandboxed release retry.'
}
for name, note in notes.items():
    r = read(w / name / 'report.json')
    r = {k:v for k,v in r.items() if k not in ['sourceHashes', 'caseExecutions']}
    r['caseStartsRecountedFromLog'] = len(re.findall(r'Test case passing \d+ arguments? .* to ', (w / name / 'tests.log').read_text()))
    r.update(interpretation=note, archiveDirectory='work/' + name)
    investigation.append(r)

measurements = []
for name in ['greyalpha-horizontal', 'rgba-vertical', 'greyalpha-larger']:
    r = read(w / (name + '-final.json'))
    assert r['exit'] == r['oracleExit'] == 0 and r['exactIndependentSamples']
    o = r['observations']
    assert (o['successfulEncodes'], o['resourceDenials'], o['preadmissionCancellations']) == (50,25,25)
    assert len(o['processHeapAfterBatches']) == len(o['batchMilliseconds']) == 20
    r['name'] = name
    r['firstToLastObservedHeapEndpointDeltaBytes'] = o['processHeapAfterBatches'][-1] - o['processHeapAfterBatches'][0]
    measurements.append(r)

env = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
command_text = lambda cmd: subprocess.check_output(cmd, env=env, text=True).strip()
report = dict(
    asOfUTC=datetime.now(timezone.utc).isoformat(),
    status='Scoped local test-only qualification complete; hosted and broader Milestone 4 gates remain open.',
    repository='https://github.com/raster-labs/SwiftJXL',
    branch=git('branch', '--show-current'), base=base, targetBaseBranch='main',
    priorQualifiedHead='c4a2b0c1ca16d0d0975b537e292608bdb5d8a3c5',
    contract='0.10.0', predecessorPin='57e81cb9e2411d1efac435b429a306a031744c1e',
    change='Tests and evidence for additional Modular precision/alpha/group-edge cases, concurrent budgets and retained-source lifetime. No production source, public API, limits, dependencies or workflow changes.',
    publicEffort=3, productionRoute='JXLSwift',
    sourceAndTestHashes=source_hashes, commonContractHashes=old['commonContractHashes'],
    unchangedPriorSourceAndTestFiles=len(old['sourceAndTestHashes']),
    validation=validation,
    independentOracle=dict(requiredByRunner=True, optionalForOfflineUnitTests=True,
        binary='/opt/homebrew/bin/djxl', binarySHA256=digest(Path('/opt/homebrew/bin/djxl')),
        version=command_text(['/opt/homebrew/bin/djxl','--version']),
        streamsPerConfiguration=74, repeatedConfigurations=4, memoryProbeStreams=3,
        codestreamHashMultisetsMatchAcrossConfigurations=True,
        uniqueCodestreamsPerConfiguration=len(streams[0]),
        sampleCheck='Exact PAM width/height/depth/maxval and every sample byte; no pixel tolerance.',
        provenance='Synthetic repository-owned samples, seed 20261014, Apache-2.0. Generator is in the tests and archived profile-fixture.swift; no external image corpus.'),
    matrix=dict(profileCount=17, internalEfforts=[3,7,8,9], profileCases=68,
        greyAlphaPrecisions=list(range(8,17)), rgbPrecisions=[9,11,13,15], rgbaPrecisions=[10,11,14,15],
        axisExtents=[1,7,17,31,511,512,513], dedicatedWorkerRefusals=4,
        concurrentBudgetCases=12, publicLifetimeCases=6,
        scope='Pairwise combinations as listed in ModularProfileCase, not a Cartesian product.'),
    concurrentMemory=measurements, memoryBuild=read(w / 'memory-build-final.json'),
    admissionInvestigation=read(w / 'admission-probe.json'),
    retainedInitialAttempts=investigation,
    environment=dict(compiler=command_text(['xcrun','swift','--version']),
        os=command_text(['sw_vers']), probeTarget='arm64-apple-macos26.0',
        measurement='Ordinary optimised probe; five warm-up and twenty measured batches per process. 2 ms malloc_zone_statistics samples and getrusage peak RSS, including harness/runtime.'),
    review=dict(productionSourceChanges=0, commonContractChanges=0,
        uncheckedConcurrencyAdded=False, fixtureLicence='Apache-2.0',
        newUnsafeCode='Test-only synchronous borrows of owning storage; no pointer survives a borrow or crosses an await.',
        performanceComparison='No runtime/hot-path change, therefore no speedup or new predecessor performance claim.'),
    limitations=[
        'Milestone 4 remains incomplete; JXLSwift remains the supported production route. No authority for a new merge, tag, release, branch deletion or production cutover.',
        'Local Swift 6.4 arm64 macOS evidence does not establish hosted Swift 6.2/Linux, native Intel, watchOS, physical-device or minimum-OS runtime behaviour.',
        'Broader two-dimensional/DC group boundaries, complete precision/layout/colour combinations and real-world corpus remain open.',
        'Public effort stays 3; internal effort 7/8/9 qualification does not enable higher public effort.',
        'Sampled heap is a lower bound on peak and includes harness/runtime; cumulative admission is neither measured heap nor process-wide admission. No exact global allocation/copy count or leak-freedom claim.',
        'Four active scopes do not prove simultaneous execution at every instruction. Memory probes cancel before admission; public lifetime tests cancel after the joined encoding borrow, not mid-worker.',
        'Earlier memory runs without exported oracle streams are archived as preliminary observations; only final runs populate the measurement table.',
        'Predecessor coverage was inventoried and earlier baseline evidence reused. Full suite/CLI and earlier fixture evidence were not rerun for this test-only slice.',
        'VarDCT/JPEG/animation, wider interoperability, feature reconciliation, consumer and release gates remain separate.'
    ])

evidence.mkdir(parents=True, exist_ok=True)
out.mkdir(exist_ok=True)
payload = json.dumps(report, indent=2) + '\n'
(evidence / 'qualification.json').write_text(payload)
(out / 'modular-profile-qualification.json').write_text(payload)
readme = '''# Modular profile qualification evidence

Synthetic fixtures and new harness source are Apache-2.0, like the repository.
See qualification.json and the adjacent engineering note for scope and limitations.

The archive contains final and initial run logs, xUnit results, source hashes,
native streams, independent PAM decodes, memory observations and harness source.
Initial failures are retained; their reports describe the executed source hashes.
The initial counter missed argument-case starts; the aggregate report recounts them.

Exact commands and environment are in each run report. Paths are host-specific:
adapt repo, work, scratch and oracle paths before reproducing. Tests are the
repository's ModularProfileTests and ModularProfileLifetimeTests. Set
SWIFTJXL_ORACLE_BIN to a directory containing djxl to require independent decoding.
SWIFTJXL_ORACLE_OUTPUT preserves those outputs. No oracle executable is in the archive.

The ordinary memory probe links the PR30 core library whose current source and
library hashes are in memory-build-final.json. The prior core build manifest and
build script are included for rebuilding; adapt their paths and select this report's
base revision. Existing libraries/executables and build caches are not archived.
memory.py and validate.py reused previous-run command manifests during this run;
the fully resolved commands are retained in their reports.

manifest.json hashes every archived entry except itself. SHA-256 of the complete
archive is in archive.json alongside it. This archive is evidence, not a portable
one-command benchmark package or a production readiness claim.
'''
(evidence / 'README.md').write_text(readme)

entries = {}
for name in configurations + list(notes):
    for p in sorted((w / name).rglob('*')):
        if p.is_file(): entries['work/' + str(p.relative_to(w))] = p.read_bytes()
for pattern in ['*.py','*.swift','*.json','*.log','*-final.jxl','*-final.pam']:
    for p in sorted(w.glob(pattern)):
        entries['work/' + p.name] = p.read_bytes()
for p in [repo / 'Tests/SwiftJXLCoreTests/ModularProfileTests.swift',
          repo / 'Tests/SwiftJXLCoreTests/ModularProfileLifetimeTests.swift']:
    entries['tested-source/' + p.name] = p.read_bytes()
old_work = Path('/Users/raster/Documents/Codex/2026-10-14/swiftjxl-milestone4-pr26-pr27-continuation/work/modular-grey-memory')
for rel in ['candidate/build.json','build.py']:
    entries['reused-core/' + rel] = (old_work / rel).read_bytes()
entries['pr30-merge.json'] = (out / 'pr30-merge.json').read_bytes()
entries['qualification.json'] = payload.encode()
entries['README.md'] = readme.encode()
manifest = {name:hashlib.sha256(data).hexdigest() for name,data in sorted(entries.items())}
entries['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = evidence / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name, date_time=(2026,10,14,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest() == h for name,h in manifest.items())
archive_report = dict(file='raw-evidence.zip', bytes=archive.stat().st_size,
                      sha256=digest(archive), entries=len(entries), manifestVerified=True)
(evidence / 'archive.json').write_text(json.dumps(archive_report,indent=2)+'\n')
shutil.copy2(archive, out / 'modular-profile-evidence.zip')
print(json.dumps(dict(validation=[{k:r[k] for k in ['configuration','exit','caseExecutions','oracleOutputs']} for r in validation],
                     sourceHashes=len(source_hashes), unchangedPriorFiles=report['unchangedPriorSourceAndTestFiles'],
                     uniqueStreams=len(streams[0]), archive=archive_report),indent=2))
