from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time, xml.etree.ElementTree as ET

w = Path(__file__).resolve().parent
repo = Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
prior = Path('/Users/raster/Documents/Codex/2026-10-14/swiftjxl-milestone4-pr26-pr27-continuation/work/modular-grey-memory')
kind = sys.argv[1]
attempt = sys.argv[2] if len(sys.argv) > 2 else 'final'
out = w / (kind + '-' + attempt)
out.mkdir(exist_ok=True)
cmd = json.loads((prior / ('sampling-' + kind + '.json')).read_text())['command']
cmd[cmd.index('--xunit-output') + 1] = str(out / 'tests.xml')
cmd[cmd.index('--filter') + 1] = 'ModularProfileTests|ModularProfileLifetimeTests'
env = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
env['CLANG_MODULE_CACHE_PATH'] = str(repo / '.build/module-cache')
env['SWIFTPM_MODULECACHE_OVERRIDE'] = str(repo / '.build/module-cache')
env['SWIFTJXL_ORACLE_BIN'] = '/opt/homebrew/bin'
env['SWIFTJXL_ORACLE_OUTPUT'] = str(out / 'oracle')
assert Path(env['SWIFTJXL_ORACLE_BIN'], 'djxl').is_file(), 'Required independent decoder absent'
hashes = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
          for folder in ['Sources', 'Tests'] for p in (repo / folder).rglob('*.swift')}
start = time.monotonic()
with (out / 'tests.log').open('w') as log:
    result = subprocess.run(cmd, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
report = dict(configuration=kind, command=cmd, exit=result.returncode, seconds=time.monotonic()-start,
              sourceHashes=hashes, environment={k:env[k] for k in ['DEVELOPER_DIR','SWIFTJXL_ORACLE_BIN','SWIFTJXL_ORACLE_OUTPUT']})
if (out / 'tests.xml').exists():
    tree = ET.parse(out / 'tests.xml').getroot()
    report['xml'] = {name:len(list(tree.iter(tag))) for name,tag in
                    [('declarations','testcase'),('failures','failure'),('errors','error'),('skips','skipped')]}
report['sourceUnchanged'] = all(hashlib.sha256((repo / p).read_bytes()).hexdigest() == h for p,h in hashes.items())
report['oracleOutputs'] = len(list((out / 'oracle').glob('*/oracle.pam')))
log = (out / 'tests.log').read_text()
report['caseExecutions'] = len(re.findall(r'Test case passing \d+ arguments? .* to ', log))
(out / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k != 'sourceHashes'}), flush=True)
print(log[-4500:], flush=True)
sys.exit(result.returncode or (0 if report.get('sourceUnchanged') else 1))
