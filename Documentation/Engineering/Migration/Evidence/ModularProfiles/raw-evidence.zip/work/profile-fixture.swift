// SPDX-License-Identifier: Apache-2.0
import Foundation
import SwiftJXLCore

/// Pairwise additions to the existing effort matrix: every greyscale-alpha
/// precision, intermediate RGB(A) precision, both 512-pixel group edges and
/// one-dimensional tails. Synthetic data belongs to this repository.
struct ModularProfileCase: Sendable {
    let width: Int, height: Int, channels: Int, bits: Int
    static let cases: [Self] = [
        .init(width: 31, height: 17, channels: 2, bits: 8),
        .init(width: 511, height: 7, channels: 2, bits: 9),
        .init(width: 512, height: 7, channels: 2, bits: 10),
        .init(width: 513, height: 7, channels: 2, bits: 11),
        .init(width: 7, height: 511, channels: 2, bits: 12),
        .init(width: 7, height: 512, channels: 2, bits: 13),
        .init(width: 7, height: 513, channels: 2, bits: 14),
        .init(width: 1, height: 513, channels: 2, bits: 15),
        .init(width: 513, height: 1, channels: 2, bits: 16),
        .init(width: 31, height: 17, channels: 3, bits: 9),
        .init(width: 513, height: 7, channels: 3, bits: 11),
        .init(width: 7, height: 513, channels: 3, bits: 13),
        .init(width: 512, height: 7, channels: 3, bits: 15),
        .init(width: 513, height: 7, channels: 4, bits: 10),
        .init(width: 7, height: 513, channels: 4, bits: 11),
        .init(width: 31, height: 17, channels: 4, bits: 14),
        .init(width: 7, height: 512, channels: 4, bits: 15)
    ]

    func pixels() -> [[UInt16]] {
        let maximum = (1 << bits) - 1
        var result = [[UInt16]](repeating: [], count: channels)
        var random: UInt32 = 20261014
        for i in 0..<(width * height) {
            for c in 0..<channels {
                random = random &* 1664525 &+ 1013904223
                let ramp = (i % width) * 71 + (i / width) * 108 + c * 113
                var value = (i % 23 < 11 ? ramp : Int(random >> 8)) & maximum
                if i % 127 == 0 { value = c % 2 == 0 ? maximum : 0 }
                if i % 127 == 1 { value = c % 2 == 0 ? 0 : maximum }
                // Nonzero colour under zero straight alpha must survive too.
                result[c].append(UInt16(value))
            }
        }
        return result
    }

    func budget(workers: Int = 1, workspace: Int = 512 * 1024 * 1024,
                cancellation: ScalarOperationCancellation? = nil) throws -> ScalarOperationBudget {
        try ScalarOperationBudget(retainedBytes: width * height * channels * 2,
            maximumWorkspaceBytes: workspace, maximumMemoryBytes: 1024 * 1024 * 1024,
            maximumDecodedBytes: 4 * 1024 * 1024, maximumCompressedBytes: 4 * 1024 * 1024,
            deadline: .now.advanced(by: .seconds(120)), maximumWorkers: workers, cancellation: cancellation)
    }

    func encode(_ pixels: [[UInt16]], effort: Int, budget: ScalarOperationBudget) throws -> Data {
        let limit = try budget.admitModularEncoder(width: width, height: height, channels: channels)
        return try ScalarEncodingWork.$current.withValue(.init(budget: budget, writerByteLimit: limit)) {
            if channels == 2 {
                if bits == 8 {
                    return try SpecModularEncoder.encodeGrayscaleAlpha8(width: width, height: height,
                        gray: pixels[0].map(UInt8.init), alpha: pixels[1].map(UInt8.init), effort: effort)
                }
                return try SpecModularEncoder.encodeGrayscaleAlpha16(width: width, height: height,
                    bitsPerSample: UInt32(bits), gray: pixels[0], alpha: pixels[1], effort: effort)
            }
            if channels == 3 {
                return try SpecModularEncoder.encodeRGB16(width: width, height: height,
                    bitsPerSample: UInt32(bits), r: pixels[0], g: pixels[1], b: pixels[2], effort: effort)
            }
            return try SpecModularEncoder.encodeRGBA16(width: width, height: height,
                bitsPerSample: UInt32(bits), r: pixels[0], g: pixels[1], b: pixels[2], a: pixels[3], effort: effort)
        }
    }
}

