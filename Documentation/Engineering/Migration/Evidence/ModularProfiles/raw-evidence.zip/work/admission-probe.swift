import Foundation
import SwiftJXLCore
@main struct Probe {
 static func main() throws {
  var rows:[[String:Any]]=[]
  for index in [10,11,13,14] { let f=ModularProfileCase.cases[index];let p=f.pixels()
   for workers in [1,2,8] { for mib in [256,512] {
    let b=try f.budget(workers:workers,workspace:mib*1024*1024)
    var row:[String:Any] = ["index":index,"workers":workers,"workspaceMiB":mib]
    do {let d=try f.encode(p,effort:9,budget:b);row["encodedBytes"]=d.count;row["passed"]=true} catch {row["error"]=String(describing:error)}
    row["reservedBytes"]=b.reservedWorkspaceBytes; rows.append(row)
   }}
  }
  print(String(decoding:try JSONSerialization.data(withJSONObject:rows,options:[.sortedKeys]),as:UTF8.self))
 }
}
