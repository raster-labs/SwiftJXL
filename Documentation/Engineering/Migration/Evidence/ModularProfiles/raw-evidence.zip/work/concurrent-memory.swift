import Foundation
import Dispatch
import Darwin
import Synchronization
import SwiftJXLCore

private func heapBytes() -> Int {
    var statistics = malloc_statistics_t()
    malloc_zone_statistics(nil, &statistics)
    return Int(statistics.size_in_use)
}
private struct Observation: Sendable {
    var active = 0, peakActive = 0, sampledHeap = 0, samples = 0
    var succeeded = 0, denied = 0, cancelled = 0
    var failures: [String] = []
}

@main struct ConcurrentMemoryProbe {
    static func main() {
        do { try run() } catch {
            print("Probe failed: \(error)")
            exit(1)
        }
    }
    static func run() throws {
        let a = CommandLine.arguments
        guard a.count == 6, let width = Int(a[1]), let height = Int(a[2]),
              let channels = Int(a[3]), let bits = Int(a[4]), let effort = Int(a[5]) else {
            throw NSError(domain: "width height channels bits effort", code: 1)
        }
        let f = ModularProfileCase(width: width, height: height, channels: channels, bits: bits)
        let pixels = f.pixels(), referenceBudget = try f.budget(workers: 2)
        let expected = try f.encode(pixels, effort: effort, budget: referenceBudget)
        if let path = ProcessInfo.processInfo.environment["SWIFTJXL_PROBE_STREAM"] {
            try expected.write(to: URL(fileURLWithPath: path))
        }
        let bound = referenceBudget.reservedWorkspaceBytes
        let state = Mutex(Observation())
        let thermal = ProcessInfo.processInfo.thermalState.rawValue
        let baselineHeap = heapBytes()
        // Ordinary build only: 2 ms samples are observations, not an exact
        // allocator peak. The sampler never alters codec admission or storage.
        let queue = DispatchQueue(label: "qualification.heap")
        let sampler = DispatchSource.makeTimerSource(queue: queue)
        sampler.schedule(deadline: .now(), repeating: .milliseconds(2))
        sampler.setEventHandler {
            let bytes = heapBytes()
            state.withLock { $0.sampledHeap = max($0.sampledHeap, bytes); $0.samples += 1 }
        }
        sampler.resume()
        var endpoints: [Int] = [], durations: [Double] = []
        for batch in 0..<25 {
            let start = ContinuousClock.now
            DispatchQueue.concurrentPerform(iterations: 4) { operation in
                state.withLock { $0.active += 1; $0.peakActive = max($0.peakActive, $0.active) }
                defer { state.withLock { $0.active -= 1 } }
                do {
                    let cancellation = ScalarOperationCancellation()
                    let budget = try f.budget(workers: 2,
                        workspace: operation == 2 ? bound - 1 : bound, cancellation: cancellation)
                    if operation == 3 { cancellation.cancel() }
                    let encoded = try f.encode(pixels, effort: effort, budget: budget)
                    guard operation < 2, encoded == expected, budget.reservedWorkspaceBytes == bound else {
                        throw NSError(domain: "Unexpected success or changed stream/admission", code: operation)
                    }
                    state.withLock { $0.succeeded += 1 }
                } catch is CancellationError {
                    state.withLock {
                        if operation == 3 { $0.cancelled += 1 } else { $0.failures.append("Unexpected cancellation") }
                    }
                } catch ScalarModularError.resourceLimit {
                    state.withLock {
                        if operation == 2 { $0.denied += 1 } else { $0.failures.append("Unexpected resource denial") }
                    }
                } catch { state.withLock { $0.failures.append(String(describing: error)) } }
            }
            let elapsed = start.duration(to: .now).components
            if batch >= 5 {
                endpoints.append(heapBytes())
                durations.append(Double(elapsed.seconds) * 1000 + Double(elapsed.attoseconds) / 1e15)
            }
        }
        sampler.cancel()
        queue.sync {} // Join any sampler handler before its owner is released.
        let observed = state.withLock { $0 }
        var usage = rusage()
        guard getrusage(RUSAGE_SELF, &usage) == 0, observed.failures.isEmpty,
              observed.active == 0, observed.succeeded == 50, observed.denied == 25,
              observed.cancelled == 25, pixels == f.pixels() else {
            throw NSError(domain: "Concurrent probe failed: \(observed.failures)", code: 2)
        }
        let report: [String: Any] = ["dimensions": [width, height], "channels": channels, "bits": bits,
            "effort": effort, "workersPerOperation": 2, "maximumInFlight": 4,
            "warmupBatches": 5, "observedBatches": 20, "peakActiveOperationScopes": observed.peakActive,
            "successfulEncodes": observed.succeeded, "resourceDenials": observed.denied,
            "preadmissionCancellations": observed.cancelled, "encodedBytes": expected.count,
            "perOperationCumulativeWorkspaceAdmission": bound,
            "processHeapBeforeBatches": baselineHeap, "sampledProcessHeapMaximum": observed.sampledHeap,
            "heapSampleCount": observed.samples, "processHeapAfterBatches": endpoints,
            "processPeakRSSBytes": usage.ru_maxrss, "batchMilliseconds": durations,
            "thermalStart": thermal, "thermalEnd": ProcessInfo.processInfo.thermalState.rawValue,
            "limitations": "Process allocator/RSS includes harness and runtime; sampled heap is a lower bound on peak. Admission is cumulative, not measured workspace. No global allocation/copy counts or public higher-effort claim. Cancellation here precedes admission; separate owning-source tests cancel after joined encoding."]
        print(String(decoding: try JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
    }
}
