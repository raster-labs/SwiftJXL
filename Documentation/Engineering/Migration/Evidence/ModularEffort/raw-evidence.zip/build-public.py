from pathlib import Path
import json,subprocess,hashlib,sys,time
w=Path(__file__).resolve().parent;name=sys.argv[1];out=w/name
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
sources=sorted((repo/'Sources/SwiftJXL').rglob('*.swift'))
flags=['-O','-g','-whole-module-optimization','-swift-version','6','-strict-concurrency=complete','-target','arm64-apple-macos26.0','-module-cache-path',str(w/'cache'),'-package-name','SwiftJXL']
command=['xcrun','swiftc',*flags,'-parse-as-library','-module-name','SwiftJXL','-I',str(out),'-emit-module','-emit-module-path',str(out/'SwiftJXL.swiftmodule'),'-emit-library','-static',*map(str,sources),'-o',str(out/'libSwiftJXL.a')]
start=time.monotonic()
with (out/'public-build.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(out/'public-build.log').read_text()[-3000:]
probe=repo/'Scripts/TestSupport/modular-operation-benchmark.swift'
link=['xcrun','swiftc',*flags,'-parse-as-library','-I',str(out),str(probe),str(out/'libSwiftJXL.a'),str(out/'libSwiftJXLCore.a'),'-o',str(out/'public-probe')]
with (out/'public-link.log').open('w') as log:r=subprocess.run(link,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(out/'public-link.log').read_text()[-3000:]
report={'name':name,'command':command,'linkCommand':link,'exit':0,'seconds':time.monotonic()-start,'sourceHashes':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'probeSHA256':hashlib.sha256(probe.read_bytes()).hexdigest(),'binarySHA256':hashlib.sha256((out/'public-probe').read_bytes()).hexdigest(),'coreBuild':str(out/'build.json')}
(out/'public-build.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'name':name,'seconds':report['seconds'],'exit':0}))
