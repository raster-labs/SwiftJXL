# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,re,shutil,subprocess,datetime,zipfile
w=Path(__file__).resolve().parent
workspace=w.parent.parent
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
evidence=repo/'Documentation/Engineering/Migration/Evidence/ModularEffort'
evidence.mkdir(parents=True,exist_ok=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((w/name).read_text())
def put(name,obj): (w/name).write_text(json.dumps(obj,indent=2)+'\n')
base='0a4abd3459143411bd93130b0a49ce63187d2481'
contract={}
for line in (repo/'Documentation/COMMON_CONTRACT_SHA256.txt').read_text().splitlines():
 h,name=line.split();assert digest(repo/'Documentation'/name)==h;contract[name]=h
snap=read('candidate/build.json')['sourceHashes']
# Only two explanatory comment blocks changed after the measured build.
def code(s):return '\n'.join(x for x in s.splitlines() if not x.lstrip().startswith('//'))
comment_changes=[]
for relative,h in snap.items():
 current=repo/relative;old=w/'candidate'/relative
 assert digest(old)==h
 if digest(current)!=h:
  assert relative=='Sources/SwiftJXLCore/Codec/SpecModularEncoder.swift'
  assert code(current.read_text())==code(old.read_text())
  comment_changes.append(relative)
validation=[]
for name in ['focused','release','asan','tsan','final-focused-retry']:
 d=read(name+'.json');assert d['exit']==0 and all(d['xml'][x]==0 for x in ['failures','errors','skips'])
 s=(w/(name+'.log')).read_text()
 args=re.findall(r'^◇ Test case passing .* to (.+?) started\.$',s,re.M)
 tests=re.findall(r'^◇ Test (?!case passing |run )(.+?) started\.$',s,re.M)
 count=len(args)+len([x for x in tests if x not in set(args)])
 assert len(tests)==d['xml']['declarations']==25 and count==191
 assert not re.search(r'WARNING: ThreadSanitizer|ERROR: AddressSanitizer|SUMMARY: (?:ThreadSanitizer|AddressSanitizer)',s)
 for relative,h in d['sourceHashes'].items():
  if digest(repo/relative)!=h:
   assert relative in comment_changes and name!='final-focused-retry'
 validation.append({'label':name,'configuration':d['configuration'],'exit':0,'declarations':25,'argumentCases':191,'failures':0,'skips':0,'sanitizerDiagnostics':0,'evidence':name+'.json'})
assert read('final-focused.json')['exit']==1
preflights=[]
for name in ['baseline','candidate']:
 d=read(name+'-preflight/report.json');assert d['status']=='passed' or d['status']=='completed'
 assert d['caseCount']==54
 preflights.append({'implementation':name,'cases':54,'status':d['status'],'evidence':name+'-preflight/report.json'})
comparisons=[]
for label in ['initial','confirmation']:
 d=read(label+'/report.json');assert d['status']=='completed'
 rows=[]
 for c in d['cases']:
  a,b=c['summaries']['baseline'],c['summaries']['candidate']
  assert a['iterations']==b['iterations']==20
  assert len({r['codestreamSHA256'] for r in c['runs']})==1
  rows.append({'case':c['name'],'medianChangePercent':c['summaries']['medianChangePercent'],'baselineMedianMS':a['medianMS'],'candidateMedianMS':b['medianMS'],'baselinePeakRSSMiB':a['processPeakRSSBytes']/1048576,'candidatePeakRSSMiB':b['processPeakRSSBytes']/1048576,'encodedBytes':b['encodedBytes'],'iterationsPerImplementation':20,'thermalStates':sorted(set(a['thermalStates']+b['thermalStates']))})
 comparisons.append({'label':label,'rows':rows,'evidence':label+'/report.json'})
experiments=[]
for label in ['row-initial','row-confirmation']:
 d=read(label+'/report.json');assert d['status']=='completed'
 assert all(c['preflight'][k]['status']=='passed' for c in d['cases'] for k in ['candidate','predecessor'])
 experiments.append({'label':label,'baselineMeaning':'The inherited predecessor key denotes current main '+base+', not JXLSwift.','decodeMedianChangesPercent':{c['name']:c['summaries']['candidate/decode']['medianChangePercent'] for c in d['cases']},'evidence':label+'/report.json'})
report={'asOfUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Local scoped qualification passed; publication and hosted qualification pending.','branch':'codex/swiftjxl-modular-effort-qualification','base':base,'predecessorPin':'57e81cb9e2411d1efac435b429a306a031744c1e','contract':'0.10.0','scope':'Internal single-section effort-4...7 activity property storage. Public API and CLI remain fixed effort 3. No higher-effort public admission or complete Milestone 4 claim.','change':'Store one Int32 property and UInt32 token per sample for the activity candidate; omit five Int32 tree properties and Int token bucket. Add checkpoints before allocation, per row and every 1024 columns; preserve predictor order, selection and bytes.','visiblePropertyPayloadBytesPerSample':{'before':36,'after':8,'saving':28,'scope':'64-bit host; excludes predictor rows, candidates, transformed planes, array capacity and learner scratch.'},'validation':validation,'preflights':preflights,'comparisons':comparisons,'benchmarkOracle':'benchmark-preflight.json verifies all twelve timed fixtures after measurement, with byte-identical outputs across all blocks.','discardedDecoderExperiment':{'decision':'Reverted: repeat colour regressions exceed the 5 percent investigation threshold. Greyscale gains do not waive colour regressions.','comparisons':experiments,'patch':'discarded-row-access.patch','candidateTest':'discarded-ModularCoordinateAccessTests.swift','testStatus':'Compiled core and independent public benchmark checks only; experimental test was not run or retained in the test target.'},'compiler':read('candidate/build.json')['compiler'],'os':read('candidate/build.json')['os'],'benchmarkTarget':'arm64-apple-macos26.0','finalCommentOnlyChanges':comment_changes,'commonContractHashes':contract,'sourceAndTestHashes':read('final-focused-retry.json')['sourceHashes'],'packageManifestSHA256':digest(repo/'Package.swift'),'limitations':['Core efforts use serial fallback and no public budget context; multi-worker higher-effort admission remains unqualified.','Full higher-effort workspace ledger, candidate error propagation, learner/sort cancellation and exact learning-sample cap remain open.','The 54-case oracle corpus omits grey-alpha, some bit depths and maximum dimensions. It does not qualify every supported profile.','Peak RSS is process-wide. Peak algorithm workspace, allocation count, copy-byte telemetry and concurrent steady state are not measured here.','No meaningful encode speed gain claimed. Effort-8 control is about 2.6 percent slower in both comparisons. Initial effort-3 latency and RSS variability is retained; it did not repeat.','Existing public Modular gaps versus the pinned predecessor remain open; the discarded experiment compared with current main only.','Local macOS arm64 Swift 6.4 evidence does not establish Swift 6.2, minimum-OS runtime, other platforms, hosted CI or release readiness.'],'retainedFailures':['initial-harness-wrong-gray8-entry: the original harness called the 16-bit entry for an 8-bit case; fixed harness, not a codec repair.','decode-profile-over-budget-attempt: guessed 4096x4096 input exceeded the unchanged resource limit; valid 4096x2048 profile retained separately.','final-focused.json: sandbox denied the compiler cache before testing; authorised retry passed.']}
put('qualification.json',report)
# Preserve commands, hashes, samples and logs, not rebuilt binaries or decoded images.
for directory in ['baseline','candidate','row-access','baseline-preflight','candidate-preflight','initial','confirmation','row-initial','row-confirmation','initial-harness-wrong-gray8-entry','decode-profile-over-budget-attempt','decode-profile']:
 for p in (w/directory).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.txt'] and 'Sources' not in p.parts:
   target=evidence/p.relative_to(w);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for p in w.iterdir():
 if p.is_file() and p.suffix in ['.py','.swift','.json','.xml','.log','.patch']:
  shutil.copy2(p,evidence/p.name)
shutil.copy2(w.parent/'modular-serial/measure.py',evidence/'public-measure.py')
shutil.copy2(w.parent/'modular-serial/cases.json',evidence/'public-cases.json')
shutil.copy2(workspace/'outputs/modular-effort-admission-audit.json',evidence/'prior-admission-audit.json')
shutil.copy2(w/'probe.swift',repo/'Scripts/TestSupport/modular-effort-benchmark.swift')
# Validation script inputs retain the exact earlier command construction.
for name in ['focused','release','asan','tsan']:
 t=evidence/'validation-command-inputs'/f'{name}.json';t.parent.mkdir(exist_ok=True);shutil.copy2(w.parent/'storage-read/validation'/f'{name}.json',t)
shutil.copy2(w/'qualification.json',workspace/'outputs/modular-effort-qualification.json')
print(json.dumps({'validation':validation,'files':len(list(evidence.rglob('*'))),'bytes':sum(p.stat().st_size for p in evidence.rglob('*') if p.is_file()),'commentOnlyChanges':comment_changes},indent=2))
