from pathlib import Path
import subprocess,json,hashlib,time
w=Path(__file__).resolve().parent;out=w/'decode-profile';out.mkdir(exist_ok=True)
binary=w.parent/'modular-serial/candidate'
record=json.loads((w.parent/'modular-serial/build.json').read_text());identity=next(c for c in record['commands'] if c['kind']=='candidate')
assert hashlib.sha256(binary.read_bytes()).hexdigest()==identity['binarySHA256']
command=[str(binary),'decode','4096','2048','1','8','100',str(out/'input.jxl')]
with (out/'probe.log').open('w') as log:
 process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 time.sleep(1)
 sample=['/usr/bin/sample',str(process.pid),'5','1','-file',str(out/'sample.txt')]
 diagnostic=subprocess.run(sample,capture_output=True,text=True,timeout=15)
 (out/'sample-command.log').write_text(diagnostic.stdout+diagnostic.stderr)
 exitcode=process.wait(timeout=180)
result={'command':command,'exit':exitcode,'sampleCommand':sample,'sampleExit':diagnostic.returncode,'binarySHA256':identity['binarySHA256'],'sourceSnapshot':record['successorBase'],'scope':'Diagnostic stack sample of the retained pre-PR23 public decoder binary. Not a controlled timing run or current-head performance qualification.'}
(out/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
