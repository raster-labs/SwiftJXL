from pathlib import Path
import json,subprocess,hashlib,sys,time
w=Path(__file__).resolve().parent;name=sys.argv[1];out=w/(name+'-preflight');out.mkdir(exist_ok=True)
cases=[('gray8',31,17,1,8,'ramp'),('gray16',32,33,1,16,'mixed'),('rgb8',31,17,3,8,'mixed'),('rgba16',33,17,4,16,'mixed'),('group-rgb8',513,17,3,8,'mixed'),('vertical-rgba16',17,513,4,16,'mixed')]
report={'name':name,'scope':'Internal core effort paths, not public higher-effort admission qualification.','binarySHA256':hashlib.sha256((w/name/'probe').read_bytes()).hexdigest(),'cases':[]}
def pixels(width,height,channels,bits,pattern):
 random=20261013;maximum=(1<<bits)-1;out=bytearray()
 for i in range(width*height):
  for c in range(channels):
   random=(random*1664525+1013904223)&0xffffffff;texture=(random>>8)&maximum;ramp=(i*71+(i//width)*37+c*113)&maximum
   value=maximum//3 if pattern=='flat' else texture if pattern=='noise' or (pattern=='mixed' and i%width>=width//2) else ramp
   if bits>8:out.append(value>>8)
   out.append(value&255)
 return bytes(out)
for label,width,height,channels,bits,pattern in cases:
 expected=pixels(width,height,channels,bits,pattern)
 for effort in range(1,10):
  stem=f'{label}-e{effort}';stream=out/(stem+'.jxl');pam=out/(stem+'.pam')
  command=[str(w/name/'probe'),str(width),str(height),str(channels),str(bits),str(effort),'0',pattern,str(stream)]
  r=subprocess.run(command,text=True,capture_output=True,timeout=180);(out/(stem+'.probe.log')).write_text(r.stdout+r.stderr)
  row={'case':label,'width':width,'height':height,'channels':channels,'bits':bits,'pattern':pattern,'effort':effort,'command':command,'exit':r.returncode}
  if r.returncode==0:
   row['probe']=json.loads(r.stdout);cmd=['/opt/homebrew/bin/djxl',str(stream),str(pam),f'--bits_per_sample={bits}','--num_threads=2','--quiet'];o=subprocess.run(cmd,text=True,capture_output=True,timeout=60);(out/(stem+'.oracle.log')).write_text(o.stdout+o.stderr);row['oracleCommand']=cmd;row['oracleExit']=o.returncode
   row['exactSamples']=False
   if o.returncode==0:
    raw=pam.read_bytes();header,payload=raw.split(b'ENDHDR\n',1);lines=header.splitlines();fields=dict(line.split(maxsplit=1) for line in lines[1:] if line and not line.startswith(b'#'))
    row['exactSamples']=lines[0]==b'P7' and int(fields[b'WIDTH'])==width and int(fields[b'HEIGHT'])==height and int(fields[b'DEPTH'])==channels and int(fields[b'MAXVAL'])==(1<<bits)-1 and payload==expected
   row['codestreamSHA256']=hashlib.sha256(stream.read_bytes()).hexdigest();row['encodedBytes']=stream.stat().st_size
   if name!='baseline':
    row['matchesBaseline']=stream.read_bytes()==(w/'baseline-preflight'/(stem+'.jxl')).read_bytes()
  report['cases'].append(row);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  if r.returncode or not row.get('exactSamples') or row.get('matchesBaseline') is False: print(json.dumps(row));sys.exit(1)
 print(label,'all nine efforts passed',flush=True)
report['status']='passed';report['caseCount']=len(report['cases']);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('All',len(report['cases']),'independent decodes passed.',flush=True)
