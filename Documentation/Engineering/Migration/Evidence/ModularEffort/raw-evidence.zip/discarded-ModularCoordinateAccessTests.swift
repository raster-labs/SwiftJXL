// SPDX-License-Identifier: Apache-2.0
import Foundation
import Testing
@testable import SwiftJXLCore

struct ModularCoordinateAccessTests {
    @Test(arguments: [8, 16], [false, true])
    func borrowedCoordinatesPreserveSamplesAndPadding(_ bits: Int, _ littleEndian: Bool) throws {
        let width = 3, height = 4, offset = 3, stride = 5, rowBytes = 19
        let layout = try ModularChannelLayout(width: width, height: height, offset: offset,
            rowBytes: rowBytes, pixelStride: stride, storageBits: bits, littleEndian: littleEndian)
        var bytes = [UInt8](repeating: 0xA5, count: layout.requiredBytes)
        var expected = bytes
        try bytes.withUnsafeMutableBytes { raw in
            var channel = BorrowedModularChannel(bytes: raw, layout: layout)
            for y in 0..<height { for x in 0..<width {
                let i = y * width + x
                let value = Int32((bits == 16 ? 0xAB00 : 0) + i)
                channel[x: x, y: y, rowWidth: width] = value
                #expect(channel[i] == value)
                #expect(channel[x: x, y: y, rowWidth: width] == value)
                let p = offset + y * rowBytes + x * stride
                let low = UInt8(truncatingIfNeeded: value), high = UInt8(truncatingIfNeeded: value >> 8)
                expected[p] = bits == 8 || littleEndian ? low : high
                if bits == 16 { expected[p + 1] = littleEndian ? high : low }
            } }
            // Same sample count with a different logical row width must retain
            // linear indexing, rather than treating padding as image pixels.
            for i in 0..<(width * height) {
                #expect(channel[x: i % 2, y: i / 2, rowWidth: 2] == channel[i])
                channel[x: i % 2, y: i / 2, rowWidth: 2] = channel[i]
            }
            let rectangle = try layout.rectangle(x: 1, y: 1, width: 2, height: 2)
            let view = BorrowedModularChannel(bytes: raw, layout: rectangle)
            for y in 0..<2 { for x in 0..<2 {
                #expect(view[x: x, y: y, rowWidth: 2] == channel[(y + 1) * width + x + 1])
            } }
        }
        #expect(bytes == expected)
    }

    @Test func arrayCoordinatesRetainLinearSemantics() {
        var samples = [Int32](repeating: 0, count: 12)
        for y in 0..<3 { for x in 0..<4 { samples[x: x, y: y, rowWidth: 4] = Int32(y * 4 + x) } }
        #expect(samples == Array(0..<12).map(Int32.init))
        for i in 0..<12 { #expect(samples[x: i % 3, y: i / 3, rowWidth: 3] == Int32(i)) }
    }
}
