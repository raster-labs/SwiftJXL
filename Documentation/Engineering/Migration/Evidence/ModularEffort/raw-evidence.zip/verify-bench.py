from pathlib import Path
import json,subprocess,hashlib,ast
w=Path(__file__).resolve().parent
tree=ast.parse((w/'preflight.py').read_text());fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='pixels');ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<retained synthetic pixel generator>','exec'),ns)
report={'scope':'Independent preflight of every timed fixture, verified after timings; both binaries and both interleavings retain byte-identical outputs.','cases':[]}
for label in ['initial','confirmation']:
 r=json.loads((w/label/'report.json').read_text());assert r['status']=='completed'
 for c in r['cases']:
  expected=ns['pixels'](c['width'],c['height'],c['channels'],c['bits'],c['pattern'])
  for run in c['runs']:
   stream=Path(run['command'][-1]);raw=stream.read_bytes();assert hashlib.sha256(raw).hexdigest()==run['codestreamSHA256']
  # All four outputs were byte-equal during timing; decode one retained representative.
  stream=Path(c['runs'][0]['command'][-1]);pam=stream.with_suffix('.pam')
  cmd=['/opt/homebrew/bin/djxl',str(stream),str(pam),f"--bits_per_sample={c['bits']}",'--num_threads=2','--quiet']
  result=subprocess.run(cmd,text=True,capture_output=True,timeout=120);stream.with_suffix('.oracle.log').write_text(result.stdout+result.stderr)
  assert result.returncode==0,result.stderr
  header,payload=pam.read_bytes().split(b'ENDHDR\n',1);lines=header.splitlines();fields=dict(line.split(maxsplit=1) for line in lines[1:] if line and not line.startswith(b'#'))
  assert lines[0]==b'P7' and int(fields[b'WIDTH'])==c['width'] and int(fields[b'HEIGHT'])==c['height'] and int(fields[b'DEPTH'])==c['channels'] and int(fields[b'MAXVAL'])==(1<<c['bits'])-1 and payload==expected
  report['cases'].append({'comparison':label,'case':c['name'],'command':cmd,'exit':result.returncode,'exactSamples':True,'codestreamSHA256':hashlib.sha256(stream.read_bytes()).hexdigest()})
report['status']='passed';(w/'benchmark-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print('Independent exact decodes passed for all 12 timed-fixture observations.')
