let oldPixels: [Int32]
do {
let width = 513, height = 17
        let pixels = (0..<(width * height)).map { Int32(($0 * 71 + ($0 / width) * 37) & 65535) }
oldPixels = pixels
}
let newPixels: [Int32]
do {
let width = 513, height = 17
        var pixels = [Int32]()
        pixels.reserveCapacity(width * height)
        for index in 0..<(width * height) {
            let row = index / width
            let value = index * 71 + row * 37
            pixels.append(Int32(value & 65535))
        }
newPixels = pixels
}
precondition(oldPixels == newPixels)
print("identical=\(oldPixels == newPixels), samples=\(newPixels.count)")
