from pathlib import Path
import json, subprocess, time
w=Path(__file__).resolve().parent
deadline=time.monotonic()+600
while not (w/'sampling-tsan.json').exists():
    if time.monotonic()>deadline: raise RuntimeError('ThreadSanitizer validation did not complete')
    time.sleep(2)
for kind in ['debug','release','asan','tsan']:
    result=json.loads((w/('sampling-'+kind+'.json')).read_text())
    assert result['exit']==0 and result['xml']['failures']==0 and result['xml']['errors']==0
print('All local build/test jobs completed; beginning controlled measurements.',flush=True)
for label in ['initial','confirmation']:
    subprocess.run(['python3',str(w/'measure.py'),label],check=True)
