from pathlib import Path
import hashlib, json, os, subprocess, time, xml.etree.ElementTree as ET

w = Path(__file__).resolve().parent
repo = Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
reports = []
for kind in ['debug', 'release', 'asan', 'tsan']:
    prior = json.loads((w.parent / 'modular-effort' / ('limits-' + kind + '.json')).read_text())
    cmd = prior['command'].copy()
    xml = w / ('sampling-' + kind + '.xml')
    cmd[cmd.index('--xunit-output') + 1] = str(xml)
    cmd[cmd.index('--filter') + 1] = 'ModularLearningSampleTests|ModularEffortTests|ModularEffortLimitTests'
    hashes = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
              for folder in ['Sources', 'Tests'] for p in (repo / folder).rglob('*.swift')}
    start = time.monotonic()
    with (w / ('sampling-' + kind + '.log')).open('w') as log:
        result = subprocess.run(cmd, cwd=repo, env={**os.environ, 'SWIFTJXL_ORACLE_BIN': '/opt/homebrew/bin'},
                                stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    report = dict(configuration=kind, command=cmd, exit=result.returncode,
                  seconds=time.monotonic()-start, sourceHashes=hashes)
    if xml.exists():
        tree = ET.parse(xml).getroot()
        report['xml'] = {name: len(list(tree.iter(tag))) for name,tag in
                         [('declarations','testcase'),('failures','failure'),('errors','error'),('skips','skipped')]}
    assert all(hashlib.sha256((repo / p).read_bytes()).hexdigest() == h for p,h in hashes.items())
    (w / ('sampling-' + kind + '.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'sourceHashes'}), flush=True)
    print((w / ('sampling-' + kind + '.log')).read_text()[-1500:], flush=True)
    assert result.returncode == 0
    reports.append(report)
