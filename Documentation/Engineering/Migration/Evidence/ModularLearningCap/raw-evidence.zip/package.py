from pathlib import Path
import hashlib, json, re, shutil, zipfile
from datetime import datetime, timezone
w=Path(__file__).resolve().parent
root=w.parent.parent
repo=Path('/Users/raster/Documents/Codex/2026-10-07/https-github-com-raster-labs-swiftjxl/work/SwiftJXL-vardct-public')
validation=[];hashes=None
for kind in ['debug','release','asan','tsan']:
    row=json.loads((w/('sampling-'+kind+'.json')).read_text())
    assert row['exit']==0 and row['xml']==dict(declarations=13,failures=0,errors=0,skips=0)
    log=(w/('sampling-'+kind+'.log')).read_text()
    assert 'WARNING: ThreadSanitizer' not in log and 'ERROR: AddressSanitizer' not in log
    groups=[int(n) for n in re.findall(r'with (\d+) test cases passed',log)]
    cases=sum(groups)+13-len(groups);assert cases==89,cases
    if hashes is None: hashes=row['sourceHashes']
    assert hashes==row['sourceHashes']
    validation.append(dict(configuration=kind,exit=0,declarations=13,argumentCases=cases,failures=0,skips=0,sanitizerDiagnostics=0,command=row['command']))
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
build=json.loads((w/'candidate/build.json').read_text())
assert all(hashes[p]==h for p,h in build['sourceHashes'].items())
contracts={}
for line in (repo/'Documentation/COMMON_CONTRACT_SHA256.txt').read_text().splitlines():
    sha,name=line.split();assert hashlib.sha256((repo/'Documentation'/name).read_bytes()).hexdigest()==sha
    contracts[name]=sha
small=json.loads((w/'candidate-preflight/report.json').read_text());assert small['status']=='passed' and small['caseCount']==54
large=json.loads((w/'large-preflight/report.json').read_text());assert large['status']=='passed' and len(large['cases'])==4
comparisons={label:json.loads((w/label/'report.json').read_text()) for label in ['initial','confirmation']}
for comparison in comparisons.values():
    assert comparison['status']=='completed' and len(comparison['cases'])==4
    for case in comparison['cases']:
        oracle=next(c for c in large['cases'] if c['name']==case['name'])
        for run in case['runs']:
            verified=next(r for r in oracle['runs'] if r['implementation']==run['implementation'])
            assert run['codestreamSHA256']==verified['sha256']
            assert run['codestreamSHA256']==hashlib.sha256(Path(run['command'][-1]).read_bytes()).hexdigest()
summary=[]
for i,c in enumerate(comparisons['initial']['cases']):
    r=comparisons['confirmation']['cases'][i];assert r['name']==c['name']
    rows=[c['summaries'],r['summaries']]
    summary.append(dict(name=c['name'],latencyChangePercent=[x['medianChangePercent'] for x in rows],sizeChangePercent=rows[0]['encodedSizeChangePercent'],peakRSSChangePercent=[(x['candidate']['processPeakRSSBytes']/x['baseline']['processPeakRSSBytes']-1)*100 for x in rows]))
report=dict(asOfUTC=datetime.now(timezone.utc).isoformat(),status='Scoped local qualification complete; publication and hosted qualification pending.',branch='codex/swiftjxl-modular-learning-cap',base='045e7883818c3ba96d24249dbed9cf3524c5db0f',dependsOn='https://github.com/raster-labs/SwiftJXL/pull/26',contract='0.10.0',predecessorPin='57e81cb9e2411d1efac435b429a306a031744c1e',change='Bound both internal effort-8/9 learners to exactly min(population,256000) uniformly distributed samples with overflow-safe arithmetic and no index array.',validation=validation,independentOracle=dict(smallUnchangedExact=54,largerBaselineAndCandidateExact=8,allTimedStreamsMatchIndependentlyDecodedHashes=True),comparisons=summary,sourceAndTestHashes=hashes,commonContractHashes=contracts,baselineReuse=json.loads((w/'baseline-reuse.json').read_text()),limitations=['Public API/CLI effort remains 3; no complete higher-effort workspace or cancellation envelope is claimed.','Only the learner sample count and sample selection are bounded here. Caller property arrays, activity sorting and learner allocations/cancellation remain open.','Above-cap streams can change because a different valid tree is learned. Corpus scope is synthetic greyscale/RGB/RGBA with four timed cases; it does not close broader compression, memory or predecessor performance gates.','Timings use serial internal core encodes without a public operation budget. Process peak RSS is not algorithm workspace telemetry.','Local Swift 6.4 macOS arm64 results do not replace hosted Swift 6.2 or minimum-OS/device qualification.'],retainedFailures=['Initial use of unqualified min inside Sequence resolved to an instance method; corrected to Swift.min. Both compiler failure logs are retained.'])
e=repo/'Documentation/Engineering/Migration/Evidence/ModularLearningCap';e.mkdir(parents=True,exist_ok=True)
for p in [e/'qualification.json',root/'outputs/modular-learning-cap-qualification.json']:
    p.write_text(json.dumps(report,indent=2)+'\n')
with zipfile.ZipFile(e/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in w.rglob('*'):
        if not p.is_file() or p.is_symlink() or p.suffix not in ['.py','.swift','.json','.log','.xml']: continue
        rel=p.relative_to(w)
        if rel.parts[0] in ['baseline','baseline-preflight','cache']: continue
        if rel.parts[0]=='candidate' and len(rel.parts)>1 and rel.parts[1]=='Sources': continue
        z.write(p,str(rel))
    z.write(w/'baseline/build.json','baseline-reused-build.json')
shutil.copyfile(e/'raw-evidence.zip',root/'outputs/modular-learning-cap-evidence.zip')
print(json.dumps({'validation':[(v['configuration'],v['argumentCases']) for v in validation],'comparisons':summary,'archiveBytes':(e/'raw-evidence.zip').stat().st_size},indent=2))
